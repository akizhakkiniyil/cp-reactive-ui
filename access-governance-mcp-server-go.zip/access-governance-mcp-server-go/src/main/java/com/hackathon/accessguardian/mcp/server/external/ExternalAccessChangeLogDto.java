package com.hackathon.accessguardian.mcp.server.external;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ExternalAccessChangeLogDto {
    private String userId;
    private String accessGroupId;
    private String changeAction; // e.g., "ASSIGN", "REMOVE"
    private String timestamp; // Assuming timestamp as String
    private String actor;
    private String reasonForChange;
}