package com.hackathon.accessguardian.mcp.server.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity// Renamed to avoid conflict with Java's Group
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Groupee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String groupId;
    private String groupName;
    private String description;
    private String resourceType; // e.g., "Application", "SharePoint", "NetworkShare"
}
