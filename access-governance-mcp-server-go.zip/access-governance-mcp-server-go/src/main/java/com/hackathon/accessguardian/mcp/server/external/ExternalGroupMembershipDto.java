package com.hackathon.accessguardian.mcp.server.external;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ExternalGroupMembershipDto {
    private String employeeIdentifier;
    private String groupIdentifier;
    private String assignmentDate; // Assuming date as String
    private String removalDate; // Nullable String
    private String assignedBySource;
}
