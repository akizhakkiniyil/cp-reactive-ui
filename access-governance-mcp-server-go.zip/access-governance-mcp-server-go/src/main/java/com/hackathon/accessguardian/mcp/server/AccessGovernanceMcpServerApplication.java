package com.hackathon.accessguardian.mcp.server;

import com.hackathon.accessguardian.mcp.server.service.AccessGovernanceService;
import org.springframework.ai.tool.ToolCallbackProvider;
import org.springframework.ai.tool.method.MethodToolCallbackProvider;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.ai.tool.ToolCallback;
import java.util.List;
import java.util.Arrays; // Needed if ToolCallbacks.from() returns an array and you need a List

@SpringBootApplication
public class AccessGovernanceMcpServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(AccessGovernanceMcpServerApplication.class, args);
    }

    /*
    @Bean
    public List<ToolCallback> mcpTools(AccessGovernanceService accessGovernanceService) {
        // Use ToolCallbacks.from() to automatically discover and wrap all @Tool annotated methods
        // from the AccessGovernanceService bean.
        // This method returns a ToolCallback, which we convert to a List.
        return Arrays.asList(ToolCallbacks.from(accessGovernanceService));
    }
    */
    @Bean
    public ToolCallbackProvider tools(AccessGovernanceService accessGovernanceService) {
        return MethodToolCallbackProvider.builder()
                .toolObjects(accessGovernanceService)
                .build();
    }


}
