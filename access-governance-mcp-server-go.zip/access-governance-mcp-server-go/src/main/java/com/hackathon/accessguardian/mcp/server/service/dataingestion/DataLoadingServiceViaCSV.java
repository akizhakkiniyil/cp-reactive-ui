package com.hackathon.accessguardian.mcp.server.service.dataingestion;

import com.hackathon.accessguardian.mcp.server.service.dataingestion.dto.EmployeeCsv;
import com.hackathon.accessguardian.mcp.server.service.dataingestion.dto.GroupMembershipCsv;
import com.hackathon.accessguardian.mcp.server.service.dataingestion.dto.GroupeeCsv;
import com.opencsv.bean.CsvToBeanBuilder;
import com.hackathon.accessguardian.mcp.server.domain.Employee;
import com.hackathon.accessguardian.mcp.server.domain.GroupMembership;
import com.hackathon.accessguardian.mcp.server.domain.Groupee;
import com.hackathon.accessguardian.mcp.server.repository.EmployeeRepository;
import com.hackathon.accessguardian.mcp.server.repository.GroupMembershipRepository;
import com.hackathon.accessguardian.mcp.server.repository.GroupRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class DataLoadingServiceViaCSV {

    private static final int BATCH_SIZE = 50;

    private final ResourceLoader resourceLoader;
    private final GroupRepository groupeeRepository;
    private final EmployeeRepository employeeRepository;
    private final GroupMembershipRepository groupMembershipRepository;

    public DataLoadingServiceViaCSV(ResourceLoader resourceLoader, GroupRepository groupeeRepository, EmployeeRepository employeeRepository, GroupMembershipRepository groupMembershipRepository) {
        this.resourceLoader = resourceLoader;
        this.groupeeRepository = groupeeRepository;
        this.employeeRepository = employeeRepository;
        this.groupMembershipRepository = groupMembershipRepository;
    }

    @Transactional
    public void loadAllData() throws Exception {
        log.info("Starting data load process...");
        loadGroups();
        loadEmployees();
        loadMemberships();
        log.info("Data load process finished successfully.");
    }

    private void loadGroups() throws Exception {
        log.info("Loading groups...");
        if (groupeeRepository.count() <= 0 ){
            Resource resource = resourceLoader.getResource("classpath:csv/groups.csv");
            try (Reader reader = new InputStreamReader(resource.getInputStream())) {
                List<GroupeeCsv> csvList = new CsvToBeanBuilder<GroupeeCsv>(reader).withType(GroupeeCsv.class).build().parse();
                List<Groupee> groups = csvList.stream().map(csv -> new Groupee(null, csv.getGroupId(), csv.getGroupName(), csv.getDescription(), csv.getResourceType())).collect(Collectors.toList());
                groupeeRepository.saveAll(groups);
            } catch (Exception e) {
                System.out.println("DataLoadingServiceViaCSV.loadGroups:" + e.getMessage());
            }
            log.info("Finished loading {} groups.", groupeeRepository.count());
        } else {
            log.info("Group data already loaded with count " + groupeeRepository.count() ) ;
        }


    }

    private void loadEmployees() throws Exception {
        log.info("Loading employees...");
        if (employeeRepository.count() <= 0 ) {
            Resource resource = resourceLoader.getResource("classpath:csv/employees.csv");
            try (Reader reader = new InputStreamReader(resource.getInputStream())) {
                List<EmployeeCsv> csvList = new CsvToBeanBuilder<EmployeeCsv>(reader).withType(EmployeeCsv.class).build().parse();
                List<Employee> employees = csvList.stream().map(csv -> new Employee(null, csv.getUserGuid(), csv.getEmployeeId(), csv.getName(), csv.getDepartment(), csv.getRole(), csv.getJoinDate(), csv.getLineManagerId(), csv.isActive(), null, null, null)).collect(Collectors.toList());
                employeeRepository.saveAll(employees);
            }
            log.info("Finished loading {} employees.", employeeRepository.count());
        } else {
            log.info("Employee data already loaded with count " + employeeRepository.count() ) ;
        }

    }

    private void loadMemberships() throws Exception {
        log.info("Loading memberships...");
        if (groupMembershipRepository.count() <= 0 ) {
            Resource resource = resourceLoader.getResource("classpath:csv/memberships.csv");
            try (Reader reader = new InputStreamReader(resource.getInputStream())) {
                List<GroupMembershipCsv> csvList = new CsvToBeanBuilder<GroupMembershipCsv>(reader).withType(GroupMembershipCsv.class).build().parse();
                List<GroupMembership> memberships = new ArrayList<>();
                for(GroupMembershipCsv csv : csvList) {
                    // Since entities are not linked via @ManyToOne, we can just copy the string IDs.
                    // This is simpler and aligns with your entity design.
                    memberships.add(new GroupMembership(null, csv.getUserGuid(), csv.getGroupId(), csv.getAssignedDate(), csv.getRevokedDate(), csv.getAssignedBy()));
                }
                groupMembershipRepository.saveAll(memberships);
            }
            log.info("Finished loading {} memberships.", groupMembershipRepository.count());
        } else {
            log.info("Groupmembershi data already loaded with count " + groupMembershipRepository.count() ) ;
        }

    }
}