package com.hackathon.accessguardian.mcp.server.service.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccessReviewSummary {
    private String employeeName;
    private String employeeRole;
    private String employeeDepartment;
    private List<GroupDiscrepancy> groupDiscrepancies;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class GroupDiscrepancy {
        private String groupName;
        private String reason; // e.g., "Employee has access, but no peers do."
        private String severity; // e.g., "Excessive", "Unusual", "Missing"
    }
}
