package com.hackathon.accessguardian.mcp.server.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String userGuid;
    private String employeeId; // Using String for employeeId
    private String name;
    private String department;
    private String role;
    private LocalDate joinDate;
    private String lineManagerId; // EmployeeId of the line manager
    private boolean active;

    @Transient // Not persisted directly, but useful for structured output
    private String lineManagerName;

    @Transient
    private List<GroupMembership> currentGroupMemberships;

    @Transient
    private List<Employee> directReports; // For hierarchy
}