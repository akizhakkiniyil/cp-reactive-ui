package com.hackathon.accessguardian.mcp.server.external;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ExternalGroupDto {
    // Example fields - adjust based on your actual external API response
    private String groupId;
    private String groupDisplayName;
    private String groupDescription;
    private String resourceAccessType; // e.g., "Application", "Network"
    // Add other fields as per your external API response
}
