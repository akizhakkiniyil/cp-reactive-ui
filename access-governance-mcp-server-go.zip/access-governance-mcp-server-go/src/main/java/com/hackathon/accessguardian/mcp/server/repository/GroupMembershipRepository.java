package com.hackathon.accessguardian.mcp.server.repository;

import com.hackathon.accessguardian.mcp.server.domain.GroupMembership;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface GroupMembershipRepository extends JpaRepository<GroupMembership, Long> {
    List<GroupMembership> findByUserGuid(String userGuid);
    List<GroupMembership> findByGroupId(String groupId);
    Optional<GroupMembership> findByUserGuidAndGroupIdAndRevokedDateIsNull(String userGuid, String groupId);
    List<GroupMembership> findByUserGuidAndAssignedDateBetween(String userGuid, LocalDate startDate, LocalDate endDate);
    List<GroupMembership> findByUserGuidAndRevokedDateIsNull(String userGuid); // Added for convenience
}
