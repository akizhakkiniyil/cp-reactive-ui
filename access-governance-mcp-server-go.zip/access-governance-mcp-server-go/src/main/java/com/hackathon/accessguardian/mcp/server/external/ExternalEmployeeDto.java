package com.hackathon.accessguardian.mcp.server.external;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ExternalEmployeeDto {
    // Example fields - adjust based on your actual external API response
    private String id;
    private String fullName;
    private String deptName;
    private String jobTitle;
    private String managerId;
    private String hireDate; // Assuming date as String from external API
    private List<String> groupIds; // Assuming group IDs are part of employee data
    // Add other fields as per your external API response
}
