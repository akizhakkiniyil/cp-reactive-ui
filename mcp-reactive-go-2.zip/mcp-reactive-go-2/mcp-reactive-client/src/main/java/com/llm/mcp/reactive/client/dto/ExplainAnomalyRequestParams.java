package com.llm.mcp.reactive.client.dto;

public record ExplainAnomalyRequestParams(
        String userGuid) {}
