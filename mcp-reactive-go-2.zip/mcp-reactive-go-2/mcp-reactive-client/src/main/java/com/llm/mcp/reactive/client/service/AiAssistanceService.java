package com.llm.mcp.reactive.client.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.messages.SystemMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.chat.prompt.PromptTemplate;
import org.springframework.ai.tool.ToolCallback; // Import the specific class
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class AiAssistanceService {

    private final ChatClient chatClient;
    // 1. Inject our new, high-performance cached Mono instead of the provider.
    private final Mono<ToolCallback[]> cachedMcpToolCallbacks;

    String prompt_for_new_access_01 =String.format(
            "An employee named %s has the role '%s' and belongs to the '%s' department. " +
                    "Based on access control best practices, which access groups should this user belong to?",
            "name", "role", "department"
    );


    public Mono<String> chatWithAi(String message) {
        log.info("chatWithAi() called with message: {}", message);

        // This is a great place for a detailed system prompt.
        String systemText = """
            You are a helpful AI assistant for access governance. You can answer questions about employees, groups,
            and access patterns by using the available tools. If you need more information, ask clarifying questions.
            Be concise and helpful. In the out put remove the leading and trailing asterix characters around attribute names
            """;

        // 2. The logic is now much cleaner and fully non-blocking.
        //    We use the cached Mono, which returns the tool list instantly
        //    after the first call.
        return cachedMcpToolCallbacks.flatMap(toolCallbacks ->
                // 1. RECOMMENDATION: Use the fluent ChatClient builder for a cleaner setup.
                chatClient.prompt()
                        .system(systemText)
                        .user(message)
                        .toolCallbacks(toolCallbacks)
                        .stream()
                        .content()
                        .collect(Collectors.joining())
                        // 2. THE FIX: Add .doOnNext() to log the final, collected response
                        //    before it's returned to the controller.
                        .doOnNext(llmResponse -> log.info("Final LLM Response to be returned: {}", llmResponse))
        );
    }

    public Mono<String> recommendAccessForNewJoiner(String userGuid) {
        String systemText = """
            You are an expert Access Governance Advisor. Your goal is to provide precise and justified group membership recommendations,
            strictly adhering to the principle of least privilege. You must use the provided tools to gather all necessary context
            about the employee, their line manager, direct reports, and peers.

            Follow these steps for your reasoning:
            1. Use the 'Get_Employee_Context_Graph' tool for the new joiner's userGuid to understand their organizational context.
            2. Analyze the 'employeeDetails', 'lineManagerDetails', 'directReports', and 'peerEmployeesInSameRoleAndDept' from the context graph.
            3. Pay close attention to the 'currentGroupMemberships' of peers.
            4. Based on the new joiner's department, role, and the access patterns of their peers,
               suggest a minimal set of group memberships.
            5. For each recommended group, provide a clear justification based on the employee's role, department, or peer access.
            6. If an employee already has access that seems excessive or unusual compared to peers, highlight it for review.
            7. Your final output MUST be a human readable format. Convert the JSON to a readable format.
            """;

        String userTextTemplate = "I need group membership recommendations for a new employee with UserGuid {userGuid}.";


        log.info("Sending access recommendation prompt for userGuid: {}", userGuid);

        // Use the cached tools Mono and flatMap into the chat client call.
        return cachedMcpToolCallbacks.flatMap(toolCallbacks ->
                // Use the fluent builder for a clean, reactive chain.
                chatClient.prompt()
                        .system(systemText)
                        .user(userSpec -> userSpec.text(userTextTemplate).param("userGuid", userGuid))
                        .toolCallbacks(toolCallbacks)
                        .stream()
                        .content()
                        .collect(Collectors.joining())
                        .doOnNext(llmResponse -> log.info("Final LLM Recommendation Response: {}", llmResponse))
        );
    }

    public Mono<String> recommendAccess(String userGuid, String employeeName, String department, String role, String lineManagerId) {
        String systemText = """
            You are an expert Access Governance Advisor. Your goal is to provide precise and justified group membership recommendations,
            strictly adhering to the principle of least privilege. You must use the provided tools to gather all necessary context
            about the employee, their line manager, direct reports, and peers.

            Follow these steps for your reasoning:
            1. Use the 'Get_Employee_Context_Graph' tool for the new joiner's userGuid to understand their organizational context.
            2. Analyze the 'employeeDetails', 'lineManagerDetails', 'directReports', and 'peerEmployeesInSameRoleAndDept' from the context graph.
            3. Pay close attention to the 'currentGroupMemberships' of peers.
            4. Based on the new joiner's department, role, and the access patterns of their peers,
               suggest a minimal set of group memberships.
            5. For each recommended group, provide a clear justification based on the employee's role, department, or peer access.
            6. If an employee already has access that seems excessive or unusual compared to peers, highlight it for review.
            7. Your final output MUST be a human readable format. Convert the JSON to a readable format.
            """;

        String userTextTemplate = """
            I need group membership recommendations for a new employee.
            User Guid: {userGuid}
            Name: {employeeName}
            Department: {department}
            Role: {role}
            Line Manager ID: {lineManagerId}
            """;

        Map<String, Object> promptParams = Map.of(
                "userGuid", userGuid,
                "employeeName", employeeName,
                "department", department,
                "role", role,
                "lineManagerId", lineManagerId
        );

        log.info("Sending access recommendation prompt for userGuid: {}", userGuid);

        // Use the cached tools Mono and flatMap into the chat client call.
        return cachedMcpToolCallbacks.flatMap(toolCallbacks ->
                // Use the fluent builder for a clean, reactive chain.
                chatClient.prompt()
                        .system(systemText)
                        .user(userSpec -> userSpec.text(userTextTemplate).params(promptParams))
                        .toolCallbacks(toolCallbacks)
                        .stream()
                        .content()
                        .collect(Collectors.joining())
                        .doOnNext(llmResponse -> log.info("Final LLM Recommendation Response: {}", llmResponse))
        );
    }

    public Mono<String> suggestGroupsForRole(String role) {
        String systemText = """
            You are an expert Access Governance Advisor. Your goal is to provide precise and justified group membership recommendations,
            strictly adhering to the principle of least privilege..

            Follow these steps for your reasoning:
            1. Use the 'suggest_groups_forR_role' tool for  suggestinf a minimal set of group memberships.
            2. For each recommended group, provide a clear justification based on the employee's role, department, or peer access.
            3. If an employee already has access that seems excessive or unusual compared to peers, highlight it for review.
            4. Your final output MUST be a human readable format. Convert the JSON to a readable format.
            """;

        String userTextTemplate = "I  group membership suggestions for role {role}."            ;



        log.info("Sending access recommendation prompt for role: {}", role);

        // Use the cached tools Mono and flatMap into the chat client call.
        return cachedMcpToolCallbacks.flatMap(toolCallbacks ->
                // Use the fluent builder for a clean, reactive chain.
                chatClient.prompt()
                        .system(systemText)
                        .user(userSpec -> userSpec.text(userTextTemplate).param("role", role))
                        .toolCallbacks(toolCallbacks)
                        .stream()
                        .content()
                        .collect(Collectors.joining())
                        .doOnNext(llmResponse -> log.info("Final LLM Recommendation Response: {}", llmResponse))
        );
    }

    /**
     * Explains a detected access anomaly in plain language.
     * Uses Detect_Access_Anomalies and Get_Employee_Details.
     * Returns a Mono for reactive execution.
     */
    public Mono<String> explainAnomaly(String userGuid) {
        log.info("Requesting anomaly explanation for employee: {}", userGuid);

        String systemText = """
            You are an AI Security Analyst. Your task is to explain detected access anomalies in clear, concise, and non-technical language.
            You must use the 'Detect_Access_Anomalies' tool to get the anomaly details and 'Get_Employee_Details' for employee context.

            Follow these steps for your reasoning:
            1. Use the 'Detect_Access_Anomalies' tool for the given user Guid.
            2. If anomalies are found, use 'Get_Employee_Details' to get the employee's basic information.
            3. For each anomaly, provide a plain language explanation of why it's unusual or risky.
            4. List the key contributing factors that led to the anomaly detection.
            5. Suggest a clear, actionable next step for IT or HR.
            6. Your final output MUST be a human readable format. Convert the JSON to a readable format.
            """;

        String userTextTemplate = "Explain any access anomalies detected for UserGuid {userGuid}.";

        // Use the cached tools Mono and flatMap into the chat client call.
        return cachedMcpToolCallbacks.flatMap(toolCallbacks ->
                // Use the fluent builder for a clean, reactive chain.
                chatClient.prompt()
                        .system(systemText)
                        .user(userSpec -> userSpec.text(userTextTemplate).param("userGuid", userGuid))
                        .toolCallbacks(toolCallbacks)
                        .stream()
                        .content()
                        .collect(Collectors.joining())
                        .doOnNext(llmResponse -> log.info("Final LLM Anomaly Explanation: {}", llmResponse))
        );
    }

    /**
     * Explains a detected access anomaly in plain language.
     * Uses Detect_Access_Anomalies and Get_Employee_Details.
     * Returns a Mono for reactive execution.
     */
    public Mono<String> sodReview(String userGuid) {
        log.info("Requesting sodReview for employee: {}", userGuid);

        String systemText = """
            You are an AI Security Analyst. Your task is to Check for Segregation of Duties (SoD) violations for a given employee based on their current group memberships

            Follow these steps for your reasoning:
            1. Use the 'check_sod_violations' tool for the given user Guid.
            2. If SOD violations are found, use 'Get_Employee_Details' to get the employee's basic information.
            3. For each violation, provide a plain language explanation of why it's viloation.
            4. List the key contributing factors that led to the viloation detection.
            5. Suggest a clear, actionable next step for IT or HR.
            6. Your final output MUST be a human readable format. Convert the JSON to a readable format.
            """;

        String userTextTemplate = "Check for Segregation of Duties (SoD) violations for a given employee with  UserGuid {userGuid}.";

        // Use the cached tools Mono and flatMap into the chat client call.
        return cachedMcpToolCallbacks.flatMap(toolCallbacks ->
                // Use the fluent builder for a clean, reactive chain.
                chatClient.prompt()
                        .system(systemText)
                        .user(userSpec -> userSpec.text(userTextTemplate).param("userGuid", userGuid))
                        .toolCallbacks(toolCallbacks)
                        .stream()
                        .content()
                        .collect(Collectors.joining())
                        .doOnNext(llmResponse -> log.info("Final SOD Review: {}", llmResponse))
        );
    }

    /**
     * Explains a detected access anomaly in plain language.
     * Uses Detect_Access_Anomalies and Get_Employee_Details.
     * Returns a Mono for reactive execution.
     */
    public Mono<String> getReviewSummaryForManagerTeam(String managerId) {
        log.info("Requesting review summary for  for manager: {}", managerId);

        String systemText = """
            You are an AI Security Analyst. Your task is to Generate a review summary for a specific manager's team for quarterly or annual audits.
            Follow these steps for your reasoning:
            1. Use the 'get_review_summary_for_manager_team' tool for the given managerId.
            2. Your final output MUST be a human readable format. Convert the JSON to a readable format.
            """;

        String userTextTemplate = "Generate a review summary for with  managerId {managerId}";

        // Use the cached tools Mono and flatMap into the chat client call.
        return cachedMcpToolCallbacks.flatMap(toolCallbacks ->
                // Use the fluent builder for a clean, reactive chain.
                chatClient.prompt()
                        .system(systemText)
                        .user(userSpec -> userSpec.text(userTextTemplate).param("managerId", managerId))
                        .toolCallbacks(toolCallbacks)
                        .stream()
                        .content()
                        .collect(Collectors.joining())
                        .doOnNext(llmResponse -> log.info("Final Review Summary : {}", llmResponse))
        );
    }

    /**
     * Explains policy drift for a group in plain language.
     * Uses Detect_Policy_Drift and Get_Group_Details.
     * Returns a Mono for reactive execution.
     */
    public Mono<String> explainPolicyDrift(String groupId, LocalDate baselineDate) {
        log.info("Requesting policy drift explanation for group: {} since {}", groupId, baselineDate);

        String systemText = """
        You are an AI Compliance Officer. Your role is to analyze and explain policy drift for access groups.
        You must use the 'Detect_Policy_Drift' tool to get the drift report and 'Get_Group_Details' for group context.

        Follow these steps for your reasoning:
        1. Use the 'Detect_Policy_Drift' tool for the given group ID and baseline date.
        2. Use 'Get_Group_Details' to understand the group's purpose.
        3. Explain in plain language what "policy drift" means for this specific group.
        4. Clearly list who was added and who was removed since the baseline date.
        5. Provide a brief assessment of the potential impact or risk of this drift.
        6. Your final output MUST be a human readable format. Convert the JSON to a readable format.
        """;

        String userTextTemplate = "Explain the policy drift for group ID: {groupId} since {baselineDate}.";

        Map<String, Object> promptParams = Map.of(
                "groupId", groupId,
                "baselineDate", baselineDate.toString()
        );

        // Use the cached tools Mono and flatMap into the chat client call.
        return cachedMcpToolCallbacks.flatMap(toolCallbacks ->
                // Use the fluent builder for a clean, reactive chain.
                chatClient.prompt()
                        .system(systemText)
                        .user(userSpec -> userSpec.text(userTextTemplate).params(promptParams))
                        .toolCallbacks(toolCallbacks)
                        .stream()
                        .content()
                        .collect(Collectors.joining())
                        .doOnNext(llmResponse -> log.info("Final LLM Policy Drift Explanation: {}", llmResponse))
        );
    }


}