package com.llm.mcp.reactive.client.service;
public enum UserIntent {
    CHAT,
    RECOMMEND_ACCESS,
    EXPLAIN_ANOMALY,
    EXPLAIN_DRIFT,
    SOD_REVIEW,
    SUGGEST_GROUPS_FOR_ROLE,
    REVIEW_SUMMARY,
    UNKNOWN; // A fallback for when the intent is unclear
}
