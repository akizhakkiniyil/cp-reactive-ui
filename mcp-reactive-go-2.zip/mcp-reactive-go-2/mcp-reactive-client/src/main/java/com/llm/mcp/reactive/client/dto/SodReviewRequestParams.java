package com.llm.mcp.reactive.client.dto;

public record SodReviewRequestParams(
        String userGuid) {}
