package com.llm.mcp.reactive.client.dto;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.llm.mcp.reactive.client.service.UserIntent;
import lombok.Data;

@Data
public class IntentExtractionResult {

    private UserIntent intent;

    // These annotations tell Jackson how to deserialize the 'parameters' field
    // into the correct concrete class based on the value of the 'intent' field.
    @JsonTypeInfo(
            use = JsonTypeInfo.Id.NAME,
            include = JsonTypeInfo.As.EXTERNAL_PROPERTY,
            property = "intent"
    )
    @JsonSubTypes({
            @JsonSubTypes.Type(value = RecommendAccessCompactRequestParams.class, name = "RECOMMEND_ACCESS"),
            @JsonSubTypes.Type(value = ExplainAnomalyRequestParams.class, name = "EXPLAIN_ANOMALY"),
            @JsonSubTypes.Type(value = ExplainDriftRequestParams.class, name = "EXPLAIN_DRIFT"),
            @JsonSubTypes.Type(value = SodReviewRequestParams.class, name = "SOD_REVIEW"),
            @JsonSubTypes.Type(value = SuggestGroupsForRoleRequestParams.class, name = "SUGGEST_GROUPS_FOR_ROLE"),
            @JsonSubTypes.Type(value = ManagerReviewRequestParams.class, name = "REVIEW_SUMMARY")
    })
    private Object parameters;
}
