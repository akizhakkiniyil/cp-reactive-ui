package com.llm.mcp.reactive.client.dto;

public record ExplainDriftRequestParams(String groupId, String baselineDate) {}
