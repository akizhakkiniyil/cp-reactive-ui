package com.llm.mcp.reactive.client.dto;

// Using a record for an immutable, concise DTO
public record RecommendAccessCompactRequestParams(
        String userGuid
) {}
