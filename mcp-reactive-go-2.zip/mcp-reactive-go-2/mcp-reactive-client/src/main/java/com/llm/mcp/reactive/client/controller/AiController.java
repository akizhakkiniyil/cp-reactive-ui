package com.llm.mcp.reactive.client.controller;

import com.llm.mcp.reactive.client.dto.*;
import com.llm.mcp.reactive.client.service.AiAssistanceService;
import com.llm.mcp.reactive.client.service.IntentRouterService;
import com.llm.mcp.reactive.client.service.MarkdownConverterService; // Import the new service
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;

@RestController
@RequestMapping("/api")
@Slf4j
@RequiredArgsConstructor
public class AiController {

    private final AiAssistanceService aiAssistanceService;
    private final IntentRouterService intentRouterService;
    private final MarkdownConverterService markdownConverter; // Inject the new service

    @PostMapping("/chat")
    public Mono<String> chatEntry(@RequestBody ChatRequest request) {
        log.info("Received intelligent chat request with input: '{}'", request.getMessage());

        return intentRouterService.route(request.getMessage())
                .flatMap(result -> {
                    log.info("Routing to intent: {} with params: {}", result.getIntent(), result.getParameters());

                    // Use a variable to hold the response Mono
                    Mono<String> responseMono;

                    switch (result.getIntent()) {
                        case RECOMMEND_ACCESS:
                            var recommendParams = (RecommendAccessCompactRequestParams) result.getParameters();
                            if (recommendParams == null || recommendParams.userGuid() == null) {
                                responseMono = Mono.just("I can help with access recommendations, but I need the employee's ID to get started.");
                            } else {
                                responseMono = aiAssistanceService.recommendAccessForNewJoiner(
                                        recommendParams.userGuid()
                                );
                            }
                            break;

                        case EXPLAIN_ANOMALY:
                            var anomalyParams = (ExplainAnomalyRequestParams) result.getParameters();
                            if (anomalyParams == null || anomalyParams.userGuid() == null) {
                                responseMono = Mono.just("I can explain security anomalies, but please provide the employee's ID.");
                            } else {
                                responseMono = aiAssistanceService.explainAnomaly(anomalyParams.userGuid());
                            }
                            break;
                        case SOD_REVIEW:
                            var sodParams = (SodReviewRequestParams) result.getParameters();
                            if (sodParams == null || sodParams.userGuid() == null) {
                                responseMono = Mono.just("I can explain Sod VBiolations, but please provide the employee's userGuid.");
                            } else {
                                responseMono = aiAssistanceService.sodReview(sodParams.userGuid());
                            }
                            break;

                        case SUGGEST_GROUPS_FOR_ROLE:
                            var groupSuggestForRoleParams = (SuggestGroupsForRoleRequestParams) result.getParameters();
                            if (groupSuggestForRoleParams == null || groupSuggestForRoleParams.role() == null) {
                                responseMono = Mono.just("I can suggest groups for role , but please provide the role's name.");
                            } else {
                                responseMono = aiAssistanceService.suggestGroupsForRole(groupSuggestForRoleParams.role());
                            }
                            break;

                        case REVIEW_SUMMARY:
                            var reviewSummarParams = (ManagerReviewRequestParams) result.getParameters();
                            if (reviewSummarParams == null || reviewSummarParams.managerId() == null) {
                                responseMono = Mono.just("I can get the review summary for manager's team , but please provide the managers  ID.");
                            } else {
                                responseMono = aiAssistanceService.getReviewSummaryForManagerTeam(reviewSummarParams.managerId());
                            }
                            break;

                        case EXPLAIN_DRIFT:
                            var driftParams = (ExplainDriftRequestParams) result.getParameters();
                            if (driftParams == null || driftParams.groupId() == null) {
                                responseMono = Mono.just("I can explain policy drift, but I need the group ID.");
                            } else {
                                try {
                                    LocalDate baselineDate = driftParams.baselineDate() != null
                                            ? LocalDate.parse(driftParams.baselineDate())
                                            : LocalDate.now().minusMonths(6);
                                    responseMono = aiAssistanceService.explainPolicyDrift(driftParams.groupId(), baselineDate);
                                } catch (DateTimeParseException e) {
                                    responseMono = Mono.just("Please provide the baseline date in YYYY-MM-DD format.");
                                }
                            }
                            break;

                        case CHAT:
                        case UNKNOWN:
                        default:
                            responseMono = aiAssistanceService.chatWithAi(request.getMessage());
                            break;
                    }

                    // Apply the Markdown to HTML conversion to the final response Mono
                    return responseMono.map(markdownConverter::convertToHtml);
                })
                .onErrorMap(e -> {
                    log.error("Error processing intelligent chat response", e);
                    return new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error processing chat response", e);
                });
    }
}