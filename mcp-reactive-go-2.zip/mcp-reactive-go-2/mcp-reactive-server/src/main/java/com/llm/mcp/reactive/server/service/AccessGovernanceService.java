package com.llm.mcp.reactive.server.service;


import com.llm.mcp.reactive.server.domain.*;
import com.llm.mcp.reactive.server.repository.*;
import com.llm.mcp.reactive.server.service.model.AccessReviewSummary;
import com.llm.mcp.reactive.server.service.model.EmployeeContextGraph;
import com.llm.mcp.reactive.server.service.model.PolicyDriftReport;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;
import com.llm.mcp.reactive.server.service.model.GroupCountProjection;
@Service
@RequiredArgsConstructor
@Slf4j
public class AccessGovernanceService {

    private final EmployeeRepository employeeRepository;
    private final GroupRepository groupRepository;
    private final GroupMembershipRepository groupMembershipRepository;
    private final AccessChangeLogRepository accessChangeLogRepository;
    private final AccessAnomalyRepository accessAnomalyRepository;
    private final SoDRuleRepository soDRuleRepository;

    // --- Basic Data Retrieval Tools ---


    // PRIMARY FIX: Change the return type to a concrete Map and use .block()
// This works around the framework's inability to handle reactive return types.
    @Tool(name = "Get_Employee_Details", description = "Retrieve full details for an employee by their unique user GUID. Input: userGuid (String).")
    public Map<String, Object> getEmployeeDetails(String userGuid) {
        final String normalizedGuid = userGuid.toLowerCase();
        log.info("Attempting to retrieve details for employee GUID: {}", normalizedGuid);

        // The reactive stream is now executed and blocked here, inside the method.
        return employeeRepository.findByUserGuidIgnoreCase(normalizedGuid)
                .map(employee -> {
                    log.info("Found employee object, now mapping to a Map.");
                    Map<String, Object> employeeDetails = new LinkedHashMap<>();
                    employeeDetails.put("userGuid", employee.getUserGuid());
                    employeeDetails.put("employeeId", employee.getEmployeeId());
                    employeeDetails.put("name", employee.getName());
                    employeeDetails.put("department", employee.getDepartment());
                    employeeDetails.put("role", employee.getRole());
                    employeeDetails.put("joinDate", employee.getJoinDate().toString());
                    employeeDetails.put("lineManagerId", employee.getLineManagerId());
                    employeeDetails.put("isActive", employee.isActive());
                    return employeeDetails;
                })
                .doOnSuccess(details -> {
                    // This log will now appear correctly.
                    log.info("Successfully retrieved details for {}: {}", normalizedGuid, details);
                })
                .doOnError(error -> log.error("[DIAGNOSTIC] Stream FAILED with error for {}:", userGuid, error))
                .doOnCancel(() -> log.warn("[DIAGNOSTIC] Stream was CANCELLED for userGuid: {}", userGuid))
                .doOnTerminate(() -> log.info("[DIAGNOSTIC] Stream TERMINATED (completed with value, empty, or error) for userGuid: {}", userGuid))
                .switchIfEmpty(Mono.defer(() -> {
                    // This log will now appear correctly if no employee is found.
                    log.warn("Stream completed EMPTY for userGuid: {}. No employee found.", normalizedGuid);
                    return Mono.empty();
                }))
                .block(); // Force execution and get the result.
    }


    @Tool(name = "Get_Employee_Details_by_Name", description = "Retrieve basic details for an employee by their full name. Returns a list if multiple match. Input: name (String).")
    public List<Map<String, Object>> getEmployeeDetailsByName(String name) {
        log.info("Retrieving details for employee(s) by name: {}", name);
        return employeeRepository.findByName(name)
                .map(employee -> {
                    Map<String, Object> employeeDetails = new LinkedHashMap<>();
                    employeeDetails.put("userGuid", employee.getUserGuid());
                    employeeDetails.put("employeeId", employee.getEmployeeId());
                    employeeDetails.put("name", employee.getName());
                    employeeDetails.put("department", employee.getDepartment());
                    employeeDetails.put("role", employee.getRole());
                    employeeDetails.put("joinDate", employee.getJoinDate().toString());
                    employeeDetails.put("lineManagerId", employee.getLineManagerId());
                    employeeDetails.put("isActive", employee.isActive());
                    return employeeDetails;
                })
                .collectList() // Collect all results into a Mono<List<...>>
                .doOnError(error -> log.error("[DIAGNOSTIC] Stream FAILED with error for {}:", name, error))
                .doOnCancel(() -> log.warn("[DIAGNOSTIC] Stream was CANCELLED for name: {}", name))
                .doOnTerminate(() -> log.info("[DIAGNOSTIC] Stream TERMINATED (completed with value, empty, or error) for name: {}", name))
                .switchIfEmpty(Mono.defer(() -> {
                    log.warn("No employees found for name: {}", name);
                    return Mono.empty();
                }))
                .block();      // Block to get the final List.
    }


    @Tool(name = "Get_Direct_Reports", description = "Get a list of direct reports for a given manager's user GUID. Input: managerUserGuid (String).")
    public List<Map<String, Object>> getDirectReports(String managerUserGuid) {
        log.info("Retrieving direct reports for manager GUID: {}", managerUserGuid);
        return employeeRepository.findByLineManagerId(managerUserGuid)
                .map(employee -> {
                    Map<String, Object> employeeDetails = new LinkedHashMap<>();
                    employeeDetails.put("userGuid", employee.getUserGuid());
                    employeeDetails.put("employeeId", employee.getEmployeeId());
                    employeeDetails.put("name", employee.getName());
                    employeeDetails.put("department", employee.getDepartment());
                    employeeDetails.put("role", employee.getRole());
                    employeeDetails.put("joinDate", employee.getJoinDate().toString());
                    employeeDetails.put("lineManagerId", employee.getLineManagerId());
                    employeeDetails.put("isActive", employee.isActive());
                    return employeeDetails;
                })
                .collectList() // Collect all results into a Mono<List<...>>
                .doOnError(error -> log.error("[DIAGNOSTIC] Stream FAILED with error for {}:", managerUserGuid, error))
                .doOnCancel(() -> log.warn("[DIAGNOSTIC] Stream was CANCELLED for managerUserGuid: {}", managerUserGuid))
                .doOnTerminate(() -> log.info("[DIAGNOSTIC] Stream TERMINATED (completed with value, empty, or error) for managerUserGuid: {}", managerUserGuid))
                .switchIfEmpty(Mono.defer(() -> {
                    log.warn("No employees found for managerUserGuid: {}", managerUserGuid);
                    return Mono.empty();
                }))
                .block();
    }

    @Tool(name = "Get_Department_Employees", description = "Get a list of all employees in a specific department. Input: department (String).")
    public List<Map<String, Object>> getDepartmentEmployees(String department) {
        log.info("Retrieving employees in department: {}", department);
        return employeeRepository.findByDepartment(department)
                .map(employee -> {
                    Map<String, Object> employeeDetails = new LinkedHashMap<>();
                    employeeDetails.put("userGuid", employee.getUserGuid());
                    employeeDetails.put("name", employee.getName());
                    employeeDetails.put("role", employee.getRole());
                    return employeeDetails;
                })
                .collectList() // Collect all results into a Mono<List<...>>
                .doOnError(error -> log.error("[DIAGNOSTIC] Stream FAILED with error for {}:", department, error))
                .doOnCancel(() -> log.warn("[DIAGNOSTIC] Stream was CANCELLED for managerUserGuid: {}", department))
                .doOnTerminate(() -> log.info("[DIAGNOSTIC] Stream TERMINATED (completed with value, empty, or error) for department: {}", department))
                .switchIfEmpty(Mono.defer(() -> {
                    log.warn("No employees found for department: {}", department);
                    return Mono.empty();
                }))
                .block();
    }



    @Tool(name = "Get_Employee_Group_Memberships", description = "Get all active group memberships for a specific employee by their user GUID. Input: userGuid (String).")
    public List<Map<String, Object>> getEmployeeGroupMemberships(String userGuid) {
        log.info("Retrieving group memberships for employee GUID: {}", userGuid);
        return groupMembershipRepository.findByUserGuidAndRevokedDateIsNull(userGuid)
                .map(membership -> {
                    Map<String, Object> membershipDetails = new LinkedHashMap<>();
                    membershipDetails.put("groupId", membership.getGroupId());
                    membershipDetails.put("assignedDate", membership.getAssignedDate().toString());
                    return membershipDetails;
                })
                .collectList() // Collect all results into a Mono<List<...>>
                .doOnError(error -> log.error("[DIAGNOSTIC] Stream FAILED with error for {}:", userGuid, error))
                .doOnCancel(() -> log.warn("[DIAGNOSTIC] Stream was CANCELLED for userGuid: {}", userGuid))
                .doOnTerminate(() -> log.info("[DIAGNOSTIC] Stream TERMINATED (completed with value, empty, or error) for userGuid: {}", userGuid))
                .switchIfEmpty(Mono.defer(() -> {
                    log.warn("No membership found for department: {}", userGuid);
                    return Mono.empty();
                }))
                .block();
    }


    @Tool(name = "Get_Group_Members", description = "Get a list of all employee user GUIDs who are members of a specific group. Input: groupId (String).")
    public List<String> getGroupMembers(String groupId) {
        log.info("Retrieving members for group: {}", groupId);
        return groupMembershipRepository.findByGroupId(groupId)
                .map(GroupMembership::getUserGuid)
                .collectList() // Collect all results into a Mono<List<...>>
                .doOnError(error -> log.error("[DIAGNOSTIC] Stream FAILED with error for {}:", groupId, error))
                .doOnCancel(() -> log.warn("[DIAGNOSTIC] Stream was CANCELLED for groupId: {}", groupId))
                .doOnTerminate(() -> log.info("[DIAGNOSTIC] Stream TERMINATED (completed with value, empty, or error) for groupId: {}", groupId))
                .switchIfEmpty(Mono.defer(() -> {
                    log.warn("No membership found for groupId: {}", groupId);
                    return Mono.empty();
                }))
                .block();
    }

    @Tool(name = "Get_Group_Details", description = "Retrieve details for a specific access group by its group ID. Input: groupId (String).")
    public Map<String, Object> getGroupDetails(String groupId) {
        log.info("Retrieving details for group: {}", groupId);
        return groupRepository.findByGroupId(groupId)
                .map(group -> {
                    Map<String, Object> groupDetails = new LinkedHashMap<>();
                    groupDetails.put("groupId", group.getGroupId());
                    groupDetails.put("groupName", group.getGroupName());
                    groupDetails.put("description", group.getDescription());
                    groupDetails.put("resourceType", group.getResourceType());
                    return groupDetails;
                })
                .doOnError(error -> log.error("[DIAGNOSTIC] Stream FAILED with error for {}:", groupId, error))
                .doOnCancel(() -> log.warn("[DIAGNOSTIC] Stream was CANCELLED for groupId: {}", groupId))
                .doOnTerminate(() -> log.info("[DIAGNOSTIC] Stream TERMINATED (completed with value, empty, or error) for groupId: {}", groupId))
                .switchIfEmpty(Mono.defer(() -> {
                    log.warn("No group found for groupId: {}", groupId);
                    return Mono.empty();
                }))
                .block();
    }

    @Tool(name = "Get_Historical_Access_Changes", description = "Retrieve historical access changes (assignments/revocations) for an employee within a date range. Input: userGuid (String), startDate (YYYY-MM-DD), endDate (YYYY-MM-DD).")
    public List<Map<String, Object>> getHistoricalAccessChanges(String userGuid, LocalDate startDate, LocalDate endDate) {
        log.info("Retrieving historical access changes for employee {} between {} and {}", userGuid, startDate, endDate);
        return accessChangeLogRepository.findByUserGuidAndChangeDateBetween(userGuid, startDate.atStartOfDay(), endDate.atTime(23, 59, 59))
                .map(logEntry -> {
                    Map<String, Object> logDetails = new LinkedHashMap<>();
                    logDetails.put("groupId", logEntry.getGroupId());
                    logDetails.put("changeType", logEntry.getChangeType());
                    logDetails.put("changeDate", logEntry.getChangeDate().toString());
                    logDetails.put("reason", logEntry.getReason());
                    return logDetails;
                })
                .collectList()
                .doOnError(error -> log.error("[DIAGNOSTIC] Stream FAILED with error for {}:", userGuid, error))
                .doOnCancel(() -> log.warn("[DIAGNOSTIC] Stream was CANCELLED for userGuid: {}", userGuid))
                .doOnTerminate(() -> log.info("[DIAGNOSTIC] Stream TERMINATED (completed with value, empty, or error) for userGuid: {}", userGuid))
                .switchIfEmpty(Mono.defer(() -> {
                    log.warn("No group found for userGuid: {}", userGuid);
                    return Mono.empty();
                }))
                .block();
    }



    @Tool(name = "Get_Employee_Context_Graph", description = "Retrieves a comprehensive context graph for an employee, including their details, line manager, direct reports, and current group memberships. Input: userGuid (String).")
    public EmployeeContextGraph getEmployeeContextGraph(String userGuid) {
        log.info("Generating context graph for employee: {}", userGuid);

        // Start the reactive chain by finding the employee.
        return employeeRepository.findByUserGuidIgnoreCase(userGuid)
                .flatMap(employee -> {
                    // Define all data-fetching operations as independent, parallelizable Monos.
                    // This is far more efficient than calling other blocking @Tool methods.

                    // 1. Fetch the manager's details.
                    Mono<Employee> managerMono = Mono.justOrEmpty(employee.getLineManagerId())
                            .flatMap(employeeRepository::findByUserGuidIgnoreCase)
                            .defaultIfEmpty(new Employee()); // Use an empty employee if no manager exists.

                    // 2. Fetch direct reports.
                    Mono<List<Map<String, Object>>> reportsMono = employeeRepository.findByLineManagerId(employee.getUserGuid())
                            .map(report -> {
                                Map<String, Object> reportDetails = new LinkedHashMap<>();
                                reportDetails.put("userGuid", report.getUserGuid());
                                reportDetails.put("name", report.getName());
                                reportDetails.put("role", report.getRole());
                                return reportDetails;
                            })
                            .collectList();

                    // 3. Fetch peers (employees in the same department, but not the user themselves).
                    Mono<List<Map<String, Object>>> peersMono = employeeRepository.findByDepartment(employee.getDepartment())
                            .filter(peer -> !peer.getUserGuid().equals(userGuid))
                            .map(peer -> {
                                Map<String, Object> peerDetails = new LinkedHashMap<>();
                                peerDetails.put("userGuid", peer.getUserGuid());
                                peerDetails.put("name", peer.getName());
                                peerDetails.put("role", peer.getRole());
                                return peerDetails;
                            })
                            .collectList();

                    // 4. Fetch group memberships.
                    Mono<List<Map<String, Object>>> membershipsMono = groupMembershipRepository.findByUserGuidAndRevokedDateIsNull(userGuid)
                            .map(membership -> {
                                Map<String, Object> membershipDetails = new LinkedHashMap<>();
                                membershipDetails.put("groupId", membership.getGroupId());
                                membershipDetails.put("assignedDate", membership.getAssignedDate().toString());
                                return membershipDetails;
                            })
                            .collectList();

                    // Use Mono.zip to execute all fetches in parallel.
                    return Mono.zip(managerMono, reportsMono, peersMono, membershipsMono)
                            .map(tuple -> {
                                Employee manager = tuple.getT1();
                                List<Map<String, Object>> reports = tuple.getT2();
                                List<Map<String, Object>> peers = tuple.getT3();
                                List<Map<String, Object>> memberships = tuple.getT4();

                                // Set the manager's name on the original employee object for the graph.
                                if (manager.getName() != null) {
                                    employee.setLineManagerName(manager.getName());
                                }

                                // Construct the final DTO with all the collected data.
                                return new EmployeeContextGraph(employee, manager, reports, peers, memberships);
                            });
                })
                .block(); // Block only once at the very end to get the final result.
    }


    @Tool(name = "Get_Peer_Group_Memberships_by_Role_and_Department",
            description = "Retrieves active group memberships for employees who share the same role and department as a specified employee. Useful for peer-based access analysis. Input: userGuid (String).")
    public List<Map<String, Object>> getPeerGroupMembershipsByRoleAndDepartment(String userGuid) {
        log.info("Retrieving peer group memberships for employee: {}", userGuid);

        return employeeRepository.findByUserGuidIgnoreCase(userGuid)
                .flatMapMany(employee ->
                        employeeRepository.findByDepartment(employee.getDepartment())
                                .filter(peer -> !peer.getUserGuid().equals(userGuid) && peer.getRole().equals(employee.getRole()))
                                .flatMap(peer -> groupMembershipRepository.findByUserGuidAndRevokedDateIsNull(peer.getUserGuid()))
                )
                .map(membership -> {
                    Map<String, Object> membershipDetails = new LinkedHashMap<>();
                    membershipDetails.put("peerUserGuid", membership.getUserGuid());
                    membershipDetails.put("groupId", membership.getGroupId());
                    membershipDetails.put("assignedDate", membership.getAssignedDate().toString());
                    return membershipDetails;
                })
                .collectList()
                .doOnError(error -> log.error("[DIAGNOSTIC] Stream FAILED with error for {}:", userGuid, error))
                .doOnCancel(() -> log.warn("[DIAGNOSTIC] Stream was CANCELLED for userGuid: {}", userGuid))
                .doOnTerminate(() -> log.info("[DIAGNOSTIC] Stream TERMINATED (completed with value, empty, or error) for userGuid: {}", userGuid))
                .switchIfEmpty(Mono.defer(() -> {
                    log.warn("No peer group membership found for userGuid: {}", userGuid);
                    return Mono.empty();
                }))
                .block();
    }


    @Tool(name = "Detect_Access_Anomalies",
            description = "Flags employees with unusual access patterns for their role/team based on historical data and peer comparisons. Returns a list of detected anomalies. Input: userGuid (String).")
    public List<AccessAnomaly> detectAccessAnomalies(String userGuid) {
        log.info("Detecting access anomalies for employee: {}", userGuid);

        return employeeRepository.findByUserGuidIgnoreCase(userGuid)
                .flatMapMany(employee -> {
                    // --- Anomaly Check 1: Missing Admin Group for an Admin Role ---
                    Flux<AccessAnomaly> missingAdminGroupFlux = Mono.just(employee)
                            .filter(e -> e.getRole().contains("Admin"))
                            .flatMapMany(adminEmployee -> {
                                Mono<Boolean> hasAdminGroupMono = groupMembershipRepository.findByUserGuidAndRevokedDateIsNull(adminEmployee.getUserGuid())
                                        .flatMap(membership -> groupRepository.findByGroupId(membership.getGroupId()))
                                        .any(group -> group.getGroupName().contains("Admin"));

                                return hasAdminGroupMono
                                        .filter(hasAdminGroup -> !hasAdminGroup)
                                        .map(b -> new AccessAnomaly(null, userGuid, "Missing_Admin_Group_for_Admin_Role",
                                                "Employee with Admin role does not have a corresponding Admin group membership.",
                                                LocalDateTime.now(), 0.8, "Detected"));
                            });

                    // --- Anomaly Check 2: Excessive Group Memberships Compared to Peers ---
                    Flux<AccessAnomaly> excessiveGroupsFlux = Mono.defer(() -> {
                                Mono<Long> employeeGroupCountMono = groupMembershipRepository.findByUserGuidAndRevokedDateIsNull(userGuid).count();
                                Mono<Long> peerDistinctGroupCountMono = employeeRepository.findByUserGuidIgnoreCase(userGuid)
                                        .flatMapMany(emp ->
                                                employeeRepository.findByDepartment(emp.getDepartment())
                                                        .filter(peer -> !peer.getUserGuid().equals(userGuid) && peer.getRole().equals(emp.getRole()))
                                                        .flatMap(peer -> groupMembershipRepository.findByUserGuidAndRevokedDateIsNull(peer.getUserGuid()))
                                        )
                                        .map(GroupMembership::getGroupId)
                                        .distinct()
                                        .count();
                                return Mono.zip(employeeGroupCountMono, peerDistinctGroupCountMono);
                            })
                            .flatMapMany(tuple -> {
                                long employeeGroupCount = tuple.getT1();
                                long peerDistinctGroupCount = tuple.getT2();
                                if (employeeGroupCount > (peerDistinctGroupCount / 2) + 5) {
                                    return Flux.just(new AccessAnomaly(null, userGuid, "Excessive_Group_Memberships",
                                            "Employee has significantly more group memberships than typical peers in the same role/department.",
                                            LocalDateTime.now(), 0.7, "Detected"));
                                }
                                return Flux.empty();
                            });

                    return Flux.merge(missingAdminGroupFlux, excessiveGroupsFlux);
                })
                .collectList()
                .doOnError(error -> log.error("[DIAGNOSTIC] Stream FAILED with error for {}:", userGuid, error))
                .doOnCancel(() -> log.warn("[DIAGNOSTIC] Stream was CANCELLED for userGuid: {}", userGuid))
                .doOnTerminate(() -> log.info("[DIAGNOSTIC] Stream TERMINATED (completed with value, empty, or error) for userGuid: {}", userGuid))
                .switchIfEmpty(Mono.defer(() -> {
                    log.warn("No paccess anomalies found for userGuid: {}", userGuid);
                    return Mono.empty();
                }))
                .block();
    }

    @Tool(name = "Generate_Access_Review_Summary",
            description = "Generates a summary for a manager during access audits, highlighting discrepancies in access compared to peers. Input: userGuid (String).")
    public AccessReviewSummary generateAccessReviewSummary(String userGuid) {
        log.info("Generating access review summary for employee: {}", userGuid);

        return employeeRepository.findByUserGuidIgnoreCase(userGuid)
                .flatMap(employee -> {
                    Mono<List<GroupMembership>> employeeMembershipsMono = groupMembershipRepository.findByUserGuidAndRevokedDateIsNull(userGuid).collectList();
                    Mono<List<GroupMembership>> peerMembershipsMono = employeeRepository.findByDepartment(employee.getDepartment())
                            .filter(peer -> !peer.getUserGuid().equals(userGuid) && peer.getRole().equals(employee.getRole()))
                            .flatMap(peer -> groupMembershipRepository.findByUserGuidAndRevokedDateIsNull(peer.getUserGuid()))
                            .collectList();
                    Mono<Long> totalPeersMono = employeeRepository.findByDepartment(employee.getDepartment())
                            .filter(e -> e.getRole().equals(employee.getRole()) && !e.getUserGuid().equals(userGuid))
                            .count();

                    return Mono.zip(employeeMembershipsMono, peerMembershipsMono, totalPeersMono)
                            .flatMap(tuple -> {
                                List<GroupMembership> employeeMemberships = tuple.getT1();
                                List<GroupMembership> peerMemberships = tuple.getT2();
                                long totalPeers = tuple.getT3();

                                Map<String, Long> peerGroupCounts = peerMemberships.stream()
                                        .collect(Collectors.groupingBy(GroupMembership::getGroupId, Collectors.counting()));

                                Flux<AccessReviewSummary.GroupDiscrepancy> discrepanciesFlux = Flux.fromIterable(employeeMemberships)
                                        .flatMap(empMembership -> {
                                            String groupId = empMembership.getGroupId();
                                            long peerCountForGroup = peerGroupCounts.getOrDefault(groupId, 0L);

                                            if (peerCountForGroup == 0) {
                                                return groupRepository.findByGroupId(groupId)
                                                        .map(groupee -> new AccessReviewSummary.GroupDiscrepancy(
                                                                groupee.getGroupName(),
                                                                "Employee has access, but no peers in the same role/department do.",
                                                                "Excessive"
                                                        ));
                                            } else if (totalPeers > 0 && (double) peerCountForGroup / totalPeers < 0.05) {
                                                return groupRepository.findByGroupId(groupId)
                                                        .map(groupee -> new AccessReviewSummary.GroupDiscrepancy(
                                                                groupee.getGroupName(),
                                                                String.format("Employee has access, but only %d%% of peers do.", (int) ((double) peerCountForGroup / totalPeers * 100)),
                                                                "Unusual"
                                                        ));
                                            } else {
                                                return Mono.empty();
                                            }
                                        });

                                return discrepanciesFlux.collectList()
                                        .map(discrepancies -> new AccessReviewSummary(
                                                employee.getName(),
                                                employee.getRole(),
                                                employee.getDepartment(),
                                                discrepancies
                                        ));
                            });
                })
                .block();
    }


    @Tool(name = "Detect_Policy_Drift",
            description = "Detects if group memberships for a specific group have drifted over time compared to a baseline. Returns a report of added and removed members. Input: groupId (String), baselineDate (YYYY-MM-DD).")
    public PolicyDriftReport detectPolicyDrift(String groupId, LocalDate baselineDate) {
        log.info("Detecting policy drift for group {} since baseline {}", groupId, baselineDate);

        return groupRepository.findByGroupId(groupId)
                .flatMap(groupee -> {
                    Mono<List<GroupMembership>> currentMembershipsMono = groupMembershipRepository.findByGroupId(groupId)
                            .filter(gm -> gm.getRevokedDate() == null || gm.getRevokedDate().isAfter(LocalDate.now()))
                            .collectList();

                    Mono<List<GroupMembership>> baselineMembershipsMono = groupMembershipRepository.findByGroupId(groupId)
                            .filter(gm -> gm.getAssignedDate().isBefore(baselineDate) && (gm.getRevokedDate() == null || gm.getRevokedDate().isAfter(baselineDate)))
                            .collectList();

                    return Mono.zip(currentMembershipsMono, baselineMembershipsMono)
                            .map(tuple -> {
                                Set<String> currentMemberGuids = tuple.getT1().stream()
                                        .map(GroupMembership::getUserGuid)
                                        .collect(Collectors.toSet());

                                Set<String> baselineMemberGuids = tuple.getT2().stream()
                                        .map(GroupMembership::getUserGuid)
                                        .collect(Collectors.toSet());

                                Set<String> addedGuids = new HashSet<>(currentMemberGuids);
                                addedGuids.removeAll(baselineMemberGuids);

                                Set<String> removedGuids = new HashSet<>(baselineMemberGuids);
                                removedGuids.removeAll(currentMemberGuids);

                                return new PolicyDriftReport(
                                        groupee.getGroupName(),
                                        baselineDate,
                                        new ArrayList<>(addedGuids),
                                        new ArrayList<>(removedGuids)
                                );
                            });
                })
                .block();
    }

    @Tool(name = "check_sod_violations",description = "Check for Segregation of Duties (SoD) violations for a given employee based on their current group memberships.")
    public SoDCheckResult checkSoDViolations(String userGuid) {
        log.info("Checking SoD violations for employee: {}", userGuid);

        // PRIMARY FIX: Use existing repository methods and standard reactive operators
        // to build the list of group IDs. This avoids type errors from custom queries.
        Mono<List<String>> employeeGroupsMono = groupMembershipRepository.findByUserGuidAndRevokedDateIsNull(userGuid)
                .map(GroupMembership::getGroupId) // Extract the String groupId from each membership
                .distinct()                        // Ensure we only have unique group IDs
                .collectList()                   // Collect into a Mono<List<String>>
                // --- THIS IS THE LOGGING YOU REQUESTED ---
                // This side-effect operator executes only when the list of groups has been successfully collected.
                .doOnSuccess(groups ->
                        log.info("[DIAGNOSTIC] SoD check: Found {} active groups for user '{}'.", groups.size(), userGuid)
                );
        Mono<List<String>> sodRulesMono = soDRuleRepository.findAll()
                .map(SoDRule::getToxicGroupCombination) // e.g., "grp_001|grp_003"
                .collectList()
                // It's good practice to add consistent logging here as well.
                .doOnSuccess(rules ->
                        log.info("[DIAGNOSTIC] SoD check: Found {} total SoD rules to evaluate.", rules.size())
                );

        return Mono.zip(employeeGroupsMono, sodRulesMono)
                // This existing log now confirms that the two parallel operations have successfully completed and been zipped.
                .doOnSuccess(tuple ->
                        log.info("[DIAGNOSTIC] SoD check for user '{}' is now comparing {} groups against {} rules.",
                                userGuid, tuple.getT1().size(), tuple.getT2().size())
                )
                .map(tuple -> {
                    List<String> employeeGroups = tuple.getT1();
                    List<String> sodRules = tuple.getT2();
                    log.info("Ajay:Diagnostic employee groups " + employeeGroups.toString());
                    log.info("Ajay:Diagnostic sodRules  " + sodRules.toString());

                    // Logic to find all SoD rules violated by the employee's group list.
                    List<String> violatingRules = sodRules.stream()
                            .filter(rule -> {
                                String[] toxicPair = rule.split("\\|");
                                log.info("Ajay:Diagnostic toxicPair  " + toxicPair.toString());
                                // A valid rule must have at least two parts.
                                if (toxicPair.length < 2) {
                                    log.info("Ajay:Diagnostic toxicPair hmm " + toxicPair.length );
                                    return false;
                                }
                                // The rule is violated if the employee is a member of BOTH toxic groups.
                                return employeeGroups.contains(toxicPair[0]) && employeeGroups.contains(toxicPair[1]);
                            })
                            .collect(Collectors.toList());

                    // Assuming SoDCheckResult is a DTO like: (String userGuid, boolean hasViolation, List<String> violatingRules)
                    return new SoDCheckResult(userGuid, !violatingRules.isEmpty(), violatingRules);
                })
                // Added consistent diagnostic logging and error handling.
                .doOnError(error -> log.error("[DIAGNOSTIC] SoD Check FAILED with error for {}:", userGuid, error))
                .doOnCancel(() -> log.warn("[DIAGNOSTIC] SoD Check was CANCELLED for userGuid: {}", userGuid))
                .doOnTerminate(() -> log.info("[DIAGNOSTIC] SoD Check TERMINATED for userGuid: {}", userGuid))
                .switchIfEmpty(Mono.defer(() -> {
                    log.warn("SoD Check completed empty for userGuid: {}. This might indicate no groups or no rules found.", userGuid);
                    // Return a non-violating result if the stream is empty.
                    return Mono.just(new SoDCheckResult(userGuid, false, Collections.emptyList()));
                }))
                // Block the stream to return a concrete object, matching the other tool methods.
                .block();
    }

    @Tool(name = "suggest_groups_for_role", description = "Suggest appropriate group memberships for a new hire or changed role based on peer analysis.")
    public List<String> suggestGroupsForRole(String role) {
        log.info("Suggesting groupsssssss for role: {}", role);
        return groupMembershipRepository.findTopGroupsByRole(role)
                // The repository now returns a Flux of our specific, type-safe projection.
                // We can now safely map it to get the groupId.
                .map(GroupCountProjection::getGroupId)
                .collectList()
                // Add consistent diagnostic logging
                .doOnError(error -> log.error("[DIAGNOSTIC] Stream FAILED with error for role {}:", role, error))
                .doOnCancel(() -> log.warn("[DIAGNOSTIC] Stream was CANCELLED for role: {}", role))
                .doOnTerminate(() -> log.info("[DIAGNOSTIC] Stream TERMINATED (completed with value, empty, or error) for role: {}", role))
                .doOnSuccess(list -> {
                    if (list.isEmpty()) {
                        log.warn("No group suggestions found for role: {}", role);
                    } else {
                        log.info("Successfully found {} group suggestions for role: {}", list.size(), role);
                    }
                })
                .block(); // Block to return a concrete List<String>
    }



    @Tool(name = "get_review_summary_for_manager_team",description = "Generate a review summary for a specific manager's team for quarterly or annual audits.")
    public String getReviewSummaryForManagerTeam(String managerId) {
        log.info("Generating review summary for manager's team: {}", managerId);

        // Start with the Flux of employees reporting to the manager
        return employeeRepository.findByLineManagerId(managerId)
                // For each employee, create their summary string reactively
                .flatMap(employee -> {
                    // In parallel, get the employee's group count and the count of their peers
                    Mono<Long> groupCountMono = groupMembershipRepository.findByUserGuidAndRevokedDateIsNull(employee.getUserGuid()).count();

                    Mono<Long> peerCountMono = employeeRepository.findByDepartment(employee.getDepartment())
                            .filter(peer -> peer.getRole().equals(employee.getRole()) && !peer.getUserGuid().equals(employee.getUserGuid()))
                            .count();

                    // Once both counts are available, create the summary string for this employee
                    return Mono.zip(groupCountMono, peerCountMono)
                            .map(tuple -> {
                                long groupCount = tuple.getT1();
                                long peerCount = tuple.getT2();
                                // Use employee.getName() as getFullName() does not exist
                                return String.format(
                                        "Team Member: %s (GUID: %s, Role: %s)\n  - Active Access Groups: %d\n  - Peers with Same Role: %d",
                                        employee.getName(),
                                        employee.getUserGuid(),
                                        employee.getRole(),
                                        groupCount,
                                        peerCount
                                );
                            });
                })
                // Collect all individual summary strings into a single string, separated by newlines
                .collect(Collectors.joining("\n\n"))
                // Create the final report header
                .map(allSummaries -> {
                    if (allSummaries.isEmpty()) {
                        return String.format("No team members found for manager with ID: %s", managerId);
                    }
                    return String.format("Access Review Summary for Manager %s's Team:\n\n%s", managerId, allSummaries);
                })
                // Add consistent diagnostic logging
                .doOnError(error -> log.error("[DIAGNOSTIC] Stream FAILED with error for managerId {}:", managerId, error))
                .doOnCancel(() -> log.warn("[DIAGNOSTIC] Stream was CANCELLED for managerId: {}", managerId))
                .doOnTerminate(() -> log.info("[DIAGNOSTIC] Stream TERMINATED (completed with value, empty, or error) for managerId: {}", managerId))
                // Block to return a concrete String, matching the other tool methods
                .block();
    }


    // Helper method to simulate initial data for H2
    public void initializeData() {
        // Employees

        Employee emp1 = new Employee(1L,"emp_001","001", "Alice Johnson", "Engineering", "Software Engineer", LocalDate.of(2022, 1, 15), "mgr_001",true,null,null,null);
        Employee emp2 = new Employee(2L,"emp_002", "002","Bob Williams", "Engineering", "Software Engineer", LocalDate.of(2022, 3, 10), "mgr_001", true,null, null,null);
        Employee emp3 = new Employee(3L,"emp_003","003", "Charlie Brown", "Marketing", "Marketing Specialist", LocalDate.of(2023, 2, 1), "mgr_002", true,null, null,null);
        Employee emp4 = new Employee(4L,"emp_004","004", "Diana Prince", "Marketing", "Marketing Specialist", LocalDate.of(2023, 5, 20), "mgr_002",false, null, null,null);
        Employee emp5 = new Employee(5L,"emp_005","005", "Eve Adams", "HR", "HR Generalist", LocalDate.of(2021, 8, 1), "mgr_003", true,null, null,null);
        Employee mgr1 = new Employee(6L,"mgr_006", "006","Frank White", "Engineering", "Engineering Manager", LocalDate.of(2020, 1, 1), "exec001",false, null, null,null);
        Employee mgr2 = new Employee(7L,"mgr_007","007", "Grace Lee", "Marketing", "Marketing Manager", LocalDate.of(2021, 6, 1), "exec001",true, null, null,null);
        Employee mgr3 = new Employee(8L,"mgr_008", "008","Henry Green", "HR", "HR Manager", LocalDate.of(2019, 10, 1), "exec001", true,null, null,null);
        Employee exec1 = new Employee(9L,"exec_009","009", "Ivy King", "Executive", "CEO", LocalDate.of(2018, 1, 1), null, true,null, null,null);

        employeeRepository.saveAll(Arrays.asList(emp1, emp2, emp3, emp4, emp5, mgr1, mgr2, exec1));

        // Groups
        Groupee g1 = new Groupee(1L,"grp_001", "Engineering_Dev_Tools", "Access to core development tools for engineers", "Application");
        Groupee g2 = new Groupee(2L,"grp_002", "Marketing_Campaign_Access", "Access to marketing campaign management platforms", "Application");
        Groupee g3 = new Groupee(3L,"grp_003", "HR_Confidential_Data", "Access to sensitive HR employee data", "Application");
        Groupee g4 = new Groupee(4L,"grp_004", "All_Employees_VPN", "VPN access for all employees", "Network");
        Groupee g5 = new Groupee(5L,"grp_005", "Engineering_Leads", "Access for engineering managers to team dashboards", "Application");
        Groupee g6 = new Groupee(6L,"grp_006", "Marketing_Analytics", "Access to marketing analytics dashboards", "Application");
        Groupee g7 = new Groupee(7L,"grp_007", "Finance_Reporting", "Access to financial reporting systems", "Application"); // Not directly used by current employees

        groupRepository.saveAll(Arrays.asList(g1, g2, g3, g4, g5, g6, g7));

        // Group Memberships
        // Alice (emp_001) - Eng
        groupMembershipRepository.save(new GroupMembership(null, "emp_001", "grp_001", LocalDate.of(2022, 1, 15), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "emp_001", "grp_004", LocalDate.of(2022, 1, 15), null, "IT"));

        // Bob (emp_002) - Eng
        groupMembershipRepository.save(new GroupMembership(null, "emp_002", "grp_001", LocalDate.of(2022, 3, 10), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "emp_002", "grp_004", LocalDate.of(2022, 3, 10), null, "IT"));

        // Charlie (emp_003) - Marketing
        groupMembershipRepository.save(new GroupMembership(null, "emp_003", "grp_002", LocalDate.of(2023, 2, 1), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "emp_003", "grp_004", LocalDate.of(2023, 2, 1), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "emp_003", "grp_006", LocalDate.of(2023, 2, 1), null, "IT"));

        // Diana (emp_004) - Marketing
        groupMembershipRepository.save(new GroupMembership(null, "emp_004", "grp_002", LocalDate.of(2023, 5, 20), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "emp_004", "grp_004", LocalDate.of(2023, 5, 20), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "emp_004", "grp_006", LocalDate.of(2023, 5, 20), null, "IT"));

        // Eve (emp_005) - HR
        groupMembershipRepository.save(new GroupMembership(null, "emp_005", "grp_003", LocalDate.of(2021, 8, 1), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "emp_005", "grp_004", LocalDate.of(2021, 8, 1), null, "IT"));

        // Frank (mgr_001) - Eng Manager
        groupMembershipRepository.save(new GroupMembership(null, "mgr_001", "grp_001", LocalDate.of(2020, 1, 1), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "mgr_001", "grp_004", LocalDate.of(2020, 1, 1), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "mgr_001", "grp_005", LocalDate.of(2020, 1, 1), null, "IT")); // Eng Leads group

        // Grace (mgr_002) - Marketing Manager
        groupMembershipRepository.save(new GroupMembership(null, "mgr_002", "grp_002", LocalDate.of(2021, 6, 1), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "mgr_002", "grp_004", LocalDate.of(2021, 6, 1), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "mgr_002", "grp_006", LocalDate.of(2021, 6, 1), null, "IT"));

        // Henry (mgr_003) - HR Manager (Not explicitly added, but can be inferred)
        groupMembershipRepository.save(new GroupMembership(null, "mgr_003", "grp_003", LocalDate.of(2019, 10, 1), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "mgr_003", "grp_004", LocalDate.of(2019, 10, 1), null, "IT"));

        // Ivy (exec001) - CEO
        groupMembershipRepository.save(new GroupMembership(null, "exec_001", "grp_004", LocalDate.of(2018, 1, 1), null, "IT"));
        groupMembershipRepository.save(new GroupMembership(null, "exec_001", "grp_007", LocalDate.of(2018, 1, 1), null, "IT")); // Finance Reporting for CEO

        // Simulate some access changes for policy drift
        accessChangeLogRepository.save(new AccessChangeLog(null, "emp_001", "grp_001", "ASSIGN", LocalDateTime.of(2022, 1, 15, 9, 0), "IT", "New hire"));
        accessChangeLogRepository.save(new AccessChangeLog(null, "emp_001", "grp_001", "REVOKE", LocalDateTime.of(2024, 1, 15, 9, 0), "IT", "Role change"));
        accessChangeLogRepository.save(new AccessChangeLog(null, "emp_001", "grp_005", "ASSIGN", LocalDateTime.of(2024, 1, 15, 9, 0), "IT", "Promoted to lead"));
        accessChangeLogRepository.save(new AccessChangeLog(null, "emp_002", "grp_001", "ASSIGN", LocalDateTime.of(2022, 3, 10, 9, 0), "IT", "New hire"));
        accessChangeLogRepository.save(new AccessChangeLog(null, "emp_003", "grp_002", "ASSIGN", LocalDateTime.of(2023, 2, 1, 9, 0), "IT", "New hire"));
        accessChangeLogRepository.save(new AccessChangeLog(null, "emp_004", "grp_002", "ASSIGN", LocalDateTime.of(2023, 5, 20, 9, 0), "IT", "New hire"));
        accessChangeLogRepository.save(new AccessChangeLog(null, "emp_005", "grp_003", "ASSIGN", LocalDateTime.of(2021, 8, 1, 9, 0), "IT", "New hire"));
        accessChangeLogRepository.save(new AccessChangeLog(null, "mgr_001", "grp_005", "ASSIGN", LocalDateTime.of(2020, 1, 1, 9, 0), "IT", "Manager role"));
        accessChangeLogRepository.save(new AccessChangeLog(null, "mgr_002", "grp_006", "ASSIGN", LocalDateTime.of(2021, 6, 1, 9, 0), "IT", "Manager role"));
    }

}
