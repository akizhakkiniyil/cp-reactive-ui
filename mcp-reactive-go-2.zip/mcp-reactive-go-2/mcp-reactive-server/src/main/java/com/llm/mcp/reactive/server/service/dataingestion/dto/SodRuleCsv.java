package com.llm.mcp.reactive.server.service.dataingestion.dto;

import com.opencsv.bean.CsvBindByName;
import lombok.Data;

@Data
public class SodRuleCsv {
    @CsvBindByName(column = "toxicGroupCombination") private String toxicGroupCombination;
}
