package com.llm.mcp.reactive.server.repository;



import com.llm.mcp.reactive.server.domain.GroupMembership;
import com.llm.mcp.reactive.server.service.model.GroupCountProjection;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDate;

public interface GroupMembershipRepository extends R2dbcRepository<GroupMembership, Long> {
    Flux<GroupMembership> findByUserGuid(String userGuid);
    Flux<GroupMembership> findByGroupId(String groupId);
    Mono<GroupMembership> findByUserGuidAndGroupIdAndRevokedDateIsNull(String userGuid, String groupId);
    Flux<GroupMembership> findByUserGuidAndAssignedDateBetween(String userGuid, LocalDate startDate, LocalDate endDate);
    Flux<GroupMembership> findByUserGuidAndRevokedDateIsNull(String userGuid);

    @Query("SELECT group_id, COUNT(user_guid) as count FROM group_membership WHERE user_guid IN " +
            "(SELECT user_guid FROM employee WHERE role = :role) GROUP BY group_id ORDER BY count DESC LIMIT 10")
    Flux<GroupCountProjection> findTopGroupsByRole(String role);

    Flux<Object> findDistinctGroupsByUserGuid(String userGuid);
}
