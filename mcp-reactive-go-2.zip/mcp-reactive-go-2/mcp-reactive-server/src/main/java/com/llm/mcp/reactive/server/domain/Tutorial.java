package com.llm.mcp.reactive.server.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

@Table("tutorial")
@Data
@Builder // Add the @Builder annotation
@NoArgsConstructor
@AllArgsConstructor
public class Tutorial {
  @Id
  private int id;
  private String title;
  private String description;
  private boolean published;

  public Tutorial(String title, String description, boolean published) {
    this.title = title;
    this.description = description;
    this.published = published;
  }
}

