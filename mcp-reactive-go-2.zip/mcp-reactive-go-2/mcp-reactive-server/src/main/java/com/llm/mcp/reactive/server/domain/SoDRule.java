package com.llm.mcp.reactive.server.domain;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Table("sod_rule")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SoDRule {
    @Id
    @Column("rule_id")
    private Long ruleId;

    @Column("toxic_group_combination")
    private String toxicGroupCombination; // e.g., "Application", "SharePoint", "NetworkShare"
}
