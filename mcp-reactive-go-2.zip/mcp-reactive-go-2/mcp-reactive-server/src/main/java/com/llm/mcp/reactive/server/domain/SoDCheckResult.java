package com.llm.mcp.reactive.server.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SoDCheckResult {
    private String employeeId;
    private boolean hasViolations;
    private List<String> violatingRules;
}
