package com.llm.mcp.reactive.server.repository;



import com.llm.mcp.reactive.server.domain.AccessAnomaly;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import reactor.core.publisher.Flux;

import java.time.LocalDateTime;

public interface AccessAnomalyRepository extends R2dbcRepository<AccessAnomaly, Long> {
    Flux<AccessAnomaly> findByUserGuid(String userGuid);
    Flux<AccessAnomaly> findByDetectedDateBetween(LocalDateTime startDate, LocalDateTime endDate);
    Flux<AccessAnomaly> findByStatus(String status);
}
