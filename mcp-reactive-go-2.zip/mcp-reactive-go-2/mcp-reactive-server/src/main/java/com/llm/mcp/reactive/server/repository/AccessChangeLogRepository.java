package com.llm.mcp.reactive.server.repository;

import com.llm.mcp.reactive.server.domain.AccessChangeLog;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import reactor.core.publisher.Flux;

import java.time.LocalDateTime;

public interface AccessChangeLogRepository extends R2dbcRepository<AccessChangeLog, Long> {
    Flux<AccessChangeLog> findByUserGuid(String userGuid);
    Flux<AccessChangeLog> findByUserGuidAndChangeDateBetween(String userGuid, LocalDateTime startDate, LocalDateTime endDate);
    Flux<AccessChangeLog> findByGroupId(String groupId);
}
