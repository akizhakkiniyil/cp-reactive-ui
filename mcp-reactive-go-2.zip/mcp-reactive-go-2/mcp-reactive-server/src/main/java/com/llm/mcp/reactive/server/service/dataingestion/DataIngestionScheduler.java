package com.llm.mcp.reactive.server.service.dataingestion;


import com.llm.mcp.reactive.server.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@EnableScheduling
@Service
@RequiredArgsConstructor
@Slf4j
public class DataIngestionScheduler {

    private final EmployeeRepository employeeRepository;
    private final GroupRepository groupRepository;
    private final GroupMembershipRepository groupMembershipRepository;
    private final AccessChangeLogRepository accessChangeLogRepository;
    private final AccessAnomalyRepository accessAnomalyRepository;
    private final DataLoadingServiceViaCSV dataLoadingServiceViaCSV;
    private final SoDRuleRepository soDRuleRepository;



    // --- Scheduled Tasks for Data Ingestion ---


    @Scheduled(fixedDelay = 300000, initialDelay = 5000)
    public void loadData() {
        log.info("Scheduled task: Running data ingestion and verification.");
        try {
            // 1. Call the reactive method and use .block() to wait for it to complete.
            // This is the correct way to bridge the reactive and synchronous worlds for this task.
            dataLoadingServiceViaCSV.loadAllData().block();
        } catch (Exception e) {
            log.error("Failed to execute data loading service.", e);
            return;
        }

        // Verification logic remains the same...
        log.info("----------- VERIFICATION -----------");
        log.info("Total Employees: {}", employeeRepository.count().block());
        log.info("Total Groups: {}", groupRepository.count().block());
        log.info("Total Memberships: {}", groupMembershipRepository.count().block());
        log.info("Total soDRules: {}", soDRuleRepository.count().block());
        log.info("------------------------------------");
    }
}