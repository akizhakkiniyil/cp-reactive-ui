CREATE TABLE IF NOT EXISTS tutorial (
    id INT NOT NULL AUTO_INCREMENT, title VARCHAR(255),
    description VARCHAR(255), published BOOLEAN, PRIMARY KEY (id));

create table IF NOT EXISTS access_anomaly (
    id bigint NOT NULL AUTO_INCREMENT,score float(53), detected_date timestamp(6),
    anomaly_type varchar(255), description varchar(255), status varchar(255),
    user_guid varchar(255), primary key (id));

create table  IF NOT EXISTS   access_change_log (
    id bigint NOT NULL AUTO_INCREMENT,change_date timestamp(6),
    change_type varchar(255), changed_by varchar(255), group_id varchar(255),
    reason varchar(255), user_guid varchar(255), primary key (id));

create table  IF NOT EXISTS employee (
    id bigint NOT NULL AUTO_INCREMENT,active boolean not null, join_date date,
    department varchar(255), employee_id varchar(255), line_manager_id varchar(255),
    name varchar(255), role varchar(255), user_guid varchar(255), primary key (id));

create table  IF NOT EXISTS groupee (
    id bigint NOT NULL AUTO_INCREMENT, description varchar(255),
    group_id varchar(255), group_name varchar(255),
    resource_type varchar(255), primary key (id));

CREATE TABLE IF NOT EXISTS sod_rule (
    rule_id bigint NOT NULL AUTO_INCREMENT,
    toxic_group_combination VARCHAR(255) UNIQUE NOT NULL,
    primary key (rule_id));

create table  IF NOT EXISTS group_membership (
    id bigint NOT NULL AUTO_INCREMENT,assigned_date date, revoked_date date,
    assigned_by varchar(255), group_id varchar(255), user_guid varchar(255), primary key (id));
