package com.llm.mcp.reactive.server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootR2dbcH2ExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
