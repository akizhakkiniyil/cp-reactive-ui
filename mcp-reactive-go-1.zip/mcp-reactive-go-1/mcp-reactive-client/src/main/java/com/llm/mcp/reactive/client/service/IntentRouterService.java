package com.llm.mcp.reactive.client.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llm.mcp.reactive.client.dto.IntentExtractionResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class IntentRouterService {

    private final ChatClient chatClient;
    private final ObjectMapper objectMapper;

    private static final String ROUTING_SYSTEM_PROMPT = """
            You are an expert routing agent. Your task is to analyze the user's message, determine their primary intent,
            and extract any relevant parameters.
            You must respond with only a single, valid JSON object that adheres to the specified format for the detected intent.
            
            Here are the possible intents and their required JSON structures:
            
            1. If the user is asking for access recommendations or permissions for a new user:
            {
              "intent": "RECOMMEND_ACCESS",
              "parameters": {
                "employeeId": "<The employee's ID, if mentioned>",
                "employeeName": "<The employee's name, if mentioned>",
                "department": "<The department, if mentioned>",
                "role": "<The role, if mentioned>",
                "lineManagerId": "<The manager's ID, if mentioned>"
              }
            }
            
            2. If the user is asking about security anomalies or unusual access for an employee:
            {
              "intent": "EXPLAIN_ANOMALY",
              "parameters": { "employeeId": "<The employee's ID>" }
            }
            
            3. If the user is asking about policy drift or changes in a group over time:
            {
              "intent": "EXPLAIN_DRIFT",
              "parameters": {
                "groupId": "<The group's ID>",
                "baselineDate": "<The date in YYYY-MM-DD format, if mentioned>"
              }
            }
            
            4. For general conversation or any request that doesn't match the others:
            {
              "intent": "CHAT",
              "parameters": null
            }
            
            If a parameter is not mentioned in the user's message, its value in the JSON should be null.
            If the intent is unclear, respond with the CHAT intent. Do not add any text or explanation outside of the JSON object.
            """;

    public Mono<IntentExtractionResult> route(String userMessage) {
        log.info("Routing and extracting entities from user message: '{}'", userMessage);

        return chatClient.prompt()
                .system(ROUTING_SYSTEM_PROMPT)
                .user(userMessage)
                // PRIMARY FIX: Use the streaming API and collect the results for a non-blocking single response.
                .stream()
                .content()
                .collect(Collectors.joining())
                // Now the rest of the chain works perfectly on a Mono<String>.
                .doOnNext(response -> log.info("Router LLM responded with JSON: '{}'", response))
                .flatMap(response -> {
                    try {
                        // Happy path: Attempt to parse and return a Mono with the successful result.
                        return Mono.just(objectMapper.readValue(response, IntentExtractionResult.class));
                    } catch (JsonProcessingException e) {
                        // Failure path: If parsing fails, return a Mono that signals an error.
                        return Mono.error(e);
                    }
                })
                .onErrorResume(JsonProcessingException.class, e -> {
                    log.error("Failed to parse JSON from LLM router. Falling back to CHAT intent.", e);
                    // If a parsing error occurs, gracefully recover by returning a fallback Mono.
                    IntentExtractionResult fallbackResult = new IntentExtractionResult();
                    fallbackResult.setIntent(UserIntent.CHAT);
                    return Mono.just(fallbackResult);
                });
    }
}