package com.llm.mcp.reactive.client.dto;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.llm.mcp.reactive.client.service.UserIntent;
import lombok.Data;

@Data
public class IntentExtractionResult {

    private UserIntent intent;

    // These annotations tell Jackson how to deserialize the 'parameters' field
    // into the correct concrete class based on the value of the 'intent' field.
    @JsonTypeInfo(
            use = JsonTypeInfo.Id.NAME,
            include = JsonTypeInfo.As.EXTERNAL_PROPERTY,
            property = "intent"
    )
    @JsonSubTypes({
            @JsonSubTypes.Type(value = RecommendAccessRequestParams.class, name = "RECOMMEND_ACCESS"),
            @JsonSubTypes.Type(value = ExplainAnomalyRequestParams.class, name = "EXPLAIN_ANOMALY"),
            @JsonSubTypes.Type(value = ExplainDriftRequestParams.class, name = "EXPLAIN_DRIFT")
    })
    private Object parameters;
}
