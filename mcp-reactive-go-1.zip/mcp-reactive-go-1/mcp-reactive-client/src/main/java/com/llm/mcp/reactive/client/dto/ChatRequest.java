package com.llm.mcp.reactive.client.dto;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO for representing an incoming chat request from the client.
 */
@Data
@NoArgsConstructor
public class ChatRequest {
    private String message;
}
