package com.llm.mcp.reactive.client.service;

import org.commonmark.node.Node;
import org.commonmark.parser.Parser;
import org.commonmark.renderer.html.HtmlRenderer;
import org.springframework.stereotype.Service;

/**
 * A service to convert Markdown text to HTML using the commonmark-java library.
 */
@Service
public class MarkdownConverterService {

    private final Parser parser;
    private final HtmlRenderer renderer;

    public MarkdownConverterService() {
        this.parser = Parser.builder().build();
        this.renderer = HtmlRenderer.builder().build();
    }

    /**
     * Converts a Markdown-formatted string into an HTML string.
     *
     * @param markdown The input string containing Markdown.
     * @return A string containing the equivalent HTML.
     */
    public String convertToHtml(String markdown) {
        if (markdown == null || markdown.isBlank()) {
            return "";
        }
        Node document = parser.parse(markdown);
        return renderer.render(document);
    }
}