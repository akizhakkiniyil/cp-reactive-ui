package com.llm.mcp.reactive.client.dto;

// Using a record for an immutable, concise DTO
public record RecommendAccessRequestParams(
        String employeeId,
        String employeeName,
        String department,
        String role,
        String lineManagerId
) {}
