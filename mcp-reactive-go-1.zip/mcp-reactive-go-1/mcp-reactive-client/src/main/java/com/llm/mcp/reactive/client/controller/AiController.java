package com.llm.mcp.reactive.client.controller;

import com.llm.mcp.reactive.client.dto.*;
import com.llm.mcp.reactive.client.service.AiAssistanceService;
import com.llm.mcp.reactive.client.service.IntentRouterService;
import com.llm.mcp.reactive.client.service.MarkdownConverterService; // Import the new service
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;

@RestController
@RequestMapping("/api")
@Slf4j
@RequiredArgsConstructor
public class AiController {

    private final AiAssistanceService aiAssistanceService;
    private final IntentRouterService intentRouterService;
    private final MarkdownConverterService markdownConverter; // Inject the new service

    @PostMapping("/chat")
    public Mono<String> chatEntry(@RequestBody ChatRequest request) {
        log.info("Received intelligent chat request with input: '{}'", request.getMessage());

        return intentRouterService.route(request.getMessage())
                .flatMap(result -> {
                    log.info("Routing to intent: {} with params: {}", result.getIntent(), result.getParameters());

                    // Use a variable to hold the response Mono
                    Mono<String> responseMono;

                    switch (result.getIntent()) {
                        case RECOMMEND_ACCESS:
                            var recommendParams = (RecommendAccessRequestParams) result.getParameters();
                            if (recommendParams == null || recommendParams.employeeId() == null) {
                                responseMono = Mono.just("I can help with access recommendations, but I need the employee's ID to get started.");
                            } else {
                                responseMono = aiAssistanceService.recommendAccess(
                                        recommendParams.employeeId(),
                                        recommendParams.employeeName(),
                                        recommendParams.department(),
                                        recommendParams.role(),
                                        recommendParams.lineManagerId()
                                );
                            }
                            break;

                        case EXPLAIN_ANOMALY:
                            var anomalyParams = (ExplainAnomalyRequestParams) result.getParameters();
                            if (anomalyParams == null || anomalyParams.employeeId() == null) {
                                responseMono = Mono.just("I can explain security anomalies, but please provide the employee's ID.");
                            } else {
                                responseMono = aiAssistanceService.explainAnomaly(anomalyParams.employeeId());
                            }
                            break;

                        case EXPLAIN_DRIFT:
                            var driftParams = (ExplainDriftRequestParams) result.getParameters();
                            if (driftParams == null || driftParams.groupId() == null) {
                                responseMono = Mono.just("I can explain policy drift, but I need the group ID.");
                            } else {
                                try {
                                    LocalDate baselineDate = driftParams.baselineDate() != null
                                            ? LocalDate.parse(driftParams.baselineDate())
                                            : LocalDate.now().minusMonths(6);
                                    responseMono = aiAssistanceService.explainPolicyDrift(driftParams.groupId(), baselineDate);
                                } catch (DateTimeParseException e) {
                                    responseMono = Mono.just("Please provide the baseline date in YYYY-MM-DD format.");
                                }
                            }
                            break;

                        case CHAT:
                        case UNKNOWN:
                        default:
                            responseMono = aiAssistanceService.chatWithAi(request.getMessage());
                            break;
                    }

                    // Apply the Markdown to HTML conversion to the final response Mono
                    return responseMono.map(markdownConverter::convertToHtml);
                })
                .onErrorMap(e -> {
                    log.error("Error processing intelligent chat response", e);
                    return new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error processing chat response", e);
                });
    }
}