package com.llm.mcp.reactive.client.config;

import org.springframework.ai.tool.ToolCallback;
import org.springframework.ai.tool.ToolCallbackProvider;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

@Configuration
public class McpClientConfig {

    /**
     * Creates a cached Mono that fetches the tool callbacks from the MCP server.
     * The .cache() operator ensures the underlying blocking call to the server
     * happens only ONCE, on the first subscription. All subsequent requests
     * for this bean will receive the cached result instantly.
     *
     * @param mcpToolCallbackProvider The auto-configured provider that connects to the server.
     * @return A hot, cached Mono containing the array of tool callbacks.
     */
    @Bean
    public Mono<ToolCallback[]> cachedMcpToolCallbacks(ToolCallbackProvider mcpToolCallbackProvider) {
        return Mono.fromCallable(mcpToolCallbackProvider::getToolCallbacks)
                .subscribeOn(Schedulers.boundedElastic())
                .cache(); // The magic is here!
    }
}