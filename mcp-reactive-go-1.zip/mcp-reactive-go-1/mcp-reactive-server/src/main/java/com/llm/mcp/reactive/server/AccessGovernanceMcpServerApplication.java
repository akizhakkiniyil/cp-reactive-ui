package com.llm.mcp.reactive.server;

import com.llm.mcp.reactive.server.service.AccessGovernanceService;
import io.modelcontextprotocol.server.McpServerFeatures;
import io.modelcontextprotocol.spec.McpSchema;
import io.r2dbc.spi.ConnectionFactory;
import org.springframework.ai.tool.ToolCallbackProvider;
import org.springframework.ai.tool.method.MethodToolCallbackProvider;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.core.io.ClassPathResource;
import org.springframework.r2dbc.connection.init.ConnectionFactoryInitializer;
import org.springframework.r2dbc.connection.init.ResourceDatabasePopulator;
import org.springframework.web.reactive.config.EnableWebFlux;

import java.util.Arrays;
import java.util.List;

@EnableWebFlux
@SpringBootApplication
public class AccessGovernanceMcpServerApplication {

    @Bean
    ConnectionFactoryInitializer initializer(ConnectionFactory connectionFactory) {

        ConnectionFactoryInitializer initializer = new ConnectionFactoryInitializer();
        initializer.setConnectionFactory(connectionFactory);
        initializer.setDatabasePopulator(new ResourceDatabasePopulator(new ClassPathResource("schema.sql")));

        return initializer;
    }

    public static void main(String[] args) {
        SpringApplication.run(AccessGovernanceMcpServerApplication.class, args);
    }

    /*
    @Bean
    public List<ToolCallback> mcpTools(AccessGovernanceService accessGovernanceService) {
        // Use ToolCallbacks.from() to automatically discover and wrap all @Tool annotated methods
        // from the AccessGovernanceService bean.
        // This method returns a ToolCallback, which we convert to a List.
        return Arrays.asList(ToolCallbacks.from(accessGovernanceService));
    }
  */
    @Bean
    public ToolCallbackProvider mcpTools(AccessGovernanceService accessGovernanceService) {
        return MethodToolCallbackProvider.builder()
                .toolObjects(accessGovernanceService)
                .build();
    }

    /*

    @Bean
    public List<McpServerFeatures.SyncPromptSpecification> prompts() {
        var prompt = new McpSchema.Prompt("persons-by-nationality", "Get persons by nationality",
                List.of(new McpSchema.PromptArgument("nationality", "Person nationality", true)));

        var promptRegistration = new McpServerFeatures.SyncPromptSpecification(prompt, (exchange, getPromptRequest) -> {
            String argument = (String) getPromptRequest.arguments().get("nationality");
            var userMessage = new McpSchema.PromptMessage(McpSchema.Role.USER,
                    new McpSchema.TextContent("How many persons come from " + argument + " ?"));
            return new McpSchema.GetPromptResult("Count persons by nationality", List.of(userMessage));
        });

        return List.of(promptRegistration);
    }
*/
}
