package com.llm.mcp.reactive.server.service.dataingestion.dto;

import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvDate;
import lombok.Data;

import java.time.LocalDate;

@Data
public class EmployeeCsv {
    @CsvBindByName(column = "userGuid") private String userGuid;
    @CsvBindByName(column = "employeeId") private String employeeId;
    @CsvBindByName(column = "name") private String name;
    @CsvBindByName(column = "department") private String department;
    @CsvBindByName(column = "role") private String role;
    @CsvDate("yyyy-MM-dd") @CsvBindByName(column = "joinDate") private LocalDate joinDate;
    @CsvBindByName(column = "lineManagerId") private String lineManagerId;
    @CsvBindByName(column = "active") private boolean active;
}
