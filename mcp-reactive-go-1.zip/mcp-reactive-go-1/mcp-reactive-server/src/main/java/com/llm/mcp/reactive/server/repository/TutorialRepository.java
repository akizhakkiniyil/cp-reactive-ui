package com.llm.mcp.reactive.server.repository;

import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;

import com.llm.mcp.reactive.server.domain.Tutorial;

import reactor.core.publisher.Flux;

@Repository
public interface TutorialRepository extends R2dbcRepository<Tutorial, Integer>{
  /**
   * Finds tutorials whose titles contain the given search term, ignoring case.
   * This provides a more user-friendly, case-agnostic search.
   *
   * @param title The search term to find within the tutorial titles.
   * @return A Flux of matching tutorials.
   */
  Flux<Tutorial> findByTitleContainingIgnoreCase(String title);
  
  Flux<Tutorial> findByPublished(boolean isPublished);
}
