package com.llm.mcp.reactive.server.repository;



import com.llm.mcp.reactive.server.domain.GroupMembership;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDate;

public interface GroupMembershipRepository extends R2dbcRepository<GroupMembership, Long> {
    Flux<GroupMembership> findByUserGuid(String userGuid);
    Flux<GroupMembership> findByGroupId(String groupId);
    Mono<GroupMembership> findByUserGuidAndGroupIdAndRevokedDateIsNull(String userGuid, String groupId);
    Flux<GroupMembership> findByUserGuidAndAssignedDateBetween(String userGuid, LocalDate startDate, LocalDate endDate);
    Flux<GroupMembership> findByUserGuidAndRevokedDateIsNull(String userGuid);
}
