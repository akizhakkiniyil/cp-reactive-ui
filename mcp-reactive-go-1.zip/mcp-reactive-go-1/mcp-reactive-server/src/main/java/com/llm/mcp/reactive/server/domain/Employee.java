package com.llm.mcp.reactive.server.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.LocalDate;
import java.util.List;

@Table("employee")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Employee {
    @Id
    @Column("id")
    private Long id;

    @Column("user_guid")
    private String userGuid;

    @Column("employee_id")
    private String employeeId;

    // 1. Add @Column annotations to all remaining fields to ensure exact mapping.
    @Column("name")
    private String name;

    @Column("department")
    private String department;

    @Column("role")
    private String role;

    @Column("join_date")
    private LocalDate joinDate;

    @Column("line_manager_id")
    private String lineManagerId;

    @Column("active")
    private boolean active;


    @Transient // Not persisted directly, but useful for structured output
    private String lineManagerName;

    @Transient
    private List<GroupMembership> currentGroupMemberships;

    @Transient
    private List<Employee> directReports; // For hierarchy
}