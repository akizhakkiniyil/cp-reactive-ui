package com.llm.mcp.reactive.server.repository;

import com.llm.mcp.reactive.server.domain.Groupee;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * Spring Data R2DBC repository for the Groupee entity.
 * Provides reactive CRUD operations and custom finder methods.
 */
@Repository
public interface GroupRepository extends R2dbcRepository<Groupee, Long> {

    Mono<Groupee> findByGroupName(String groupName);
    Flux<Groupee> findByResourceType(String resourceType);
    Mono<Groupee> findByGroupId(String groupId);
}