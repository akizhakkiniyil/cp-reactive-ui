package com.llm.mcp.reactive.server.service.dataingestion.dto;

import com.opencsv.bean.CsvBindByName;
import lombok.Data;

@Data
public class GroupeeCsv {
    @CsvBindByName(column = "groupId") private String groupId;
    @CsvBindByName(column = "groupName") private String groupName;
    @CsvBindByName(column = "description") private String description;
    @CsvBindByName(column = "resourceType") private String resourceType;
}
