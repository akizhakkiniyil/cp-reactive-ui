package com.llm.mcp.reactive.server.repository;



import com.llm.mcp.reactive.server.domain.Employee;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface EmployeeRepository extends R2dbcRepository<Employee, Long> {
    Flux<Employee> findByDepartment(String department);
    Flux<Employee> findByRole(String role);
    Flux<Employee> findByLineManagerId(String lineManagerId);
    Flux<Employee> findByName(String name);
    Mono<Employee> findByEmployeeId(String employeeId);
    Mono<Employee>  findByUserGuidIgnoreCase(String userGuid);
}
