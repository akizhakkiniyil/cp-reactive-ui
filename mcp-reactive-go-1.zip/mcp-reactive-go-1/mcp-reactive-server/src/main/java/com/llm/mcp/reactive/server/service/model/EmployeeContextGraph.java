package com.llm.mcp.reactive.server.service.model;

import com.llm.mcp.reactive.server.domain.Employee;
import com.llm.mcp.reactive.server.domain.GroupMembership;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

/**
 * A DTO representing the complete context for a single employee.
 * It includes the employee's own details, their manager, their direct reports,
 * their peers, and their current group memberships.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeContextGraph {

    private Employee employee;
    private Employee lineManager;
    private List<Map<String, Object>> directReports;
    private List<Map<String, Object>> peers;
    private List<Map<String, Object>> groupMemberships;

}