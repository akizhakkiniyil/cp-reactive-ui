package com.llm.mcp.reactive.server.controller;

import com.llm.mcp.reactive.server.domain.Employee;
import com.llm.mcp.reactive.server.repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * REST controller for managing Employees.
 * This controller exposes reactive endpoints for all standard CRUD operations
 * and custom queries defined in the EmployeeRepository.
 */
@Slf4j
@RestController
@RequestMapping("/api/employees")
@RequiredArgsConstructor
public class EmployeeController {

    private final EmployeeRepository employeeRepository;

    // --- Endpoints for standard CRUD operations ---

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public Flux<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Mono<Employee> createEmployee(@RequestBody Employee employee) {
        // For a true "create" operation, ensure the ID is null
        // so the database can generate a new one.
       //employee.setEmployeeId(null);
        return employeeRepository.save(employee);
    }

    @GetMapping("/{id}")
    public Mono<ResponseEntity<Employee>> getEmployeeById(@PathVariable long id) {
        return employeeRepository.findById(id)
                .map(ResponseEntity::ok) // Maps the found employee to a 200 OK response
                .defaultIfEmpty(ResponseEntity.notFound().build()); // Returns 404 if the Mono is empty
    }

    @PutMapping("/{id}")
    public Mono<ResponseEntity<Employee>> updateEmployee(@PathVariable long id, @RequestBody Employee employee) {
        return employeeRepository.findById(id)
                .flatMap(existingEmployee -> {
                    // Update properties of the existing employee
                    existingEmployee.setName(employee.getName());
                    existingEmployee.setRole(employee.getRole());
                    existingEmployee.setLineManagerId(employee.getLineManagerId());
                    return employeeRepository.save(existingEmployee);
                })
                .map(ResponseEntity::ok) // Return the updated employee with 200 OK
                .defaultIfEmpty(ResponseEntity.notFound().build()); // Or 404 if not found
    }

    @DeleteMapping("/{id}")
    public Mono<ResponseEntity<Void>> deleteEmployee(@PathVariable long id) {
        // First, check if the employee exists to provide a proper 404 response
        return employeeRepository.findById(id)
                .flatMap(existingEmployee ->
                        employeeRepository.delete(existingEmployee)
                                .then(Mono.just(new ResponseEntity<Void>(HttpStatus.NO_CONTENT)))
                )
                .defaultIfEmpty(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @DeleteMapping
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public Mono<Void> deleteAllEmployees() {
        return employeeRepository.deleteAll();
    }

    // --- Endpoints for custom repository methods ---

    @GetMapping("/search/by-name")
    public Flux<Employee> getEmployeeByFullName(@RequestParam String name) {
        return employeeRepository.findByName(name)
                .doOnNext(employee -> log.debug("Found employee by name: {}", employee))
                .switchIfEmpty(Flux.defer(() -> {
                    log.warn("No employees found for name: {}", name);
                    return Flux.empty();
                }));
    }

    @GetMapping("/search/by-lineManagerId")
    public Flux<Employee> getEmployeesByLineManagerId(@RequestParam String managerId) {
        return employeeRepository.findByLineManagerId(managerId);
    }


}