package com.llm.mcp.reactive.server.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Table("access_change_log")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccessChangeLog {
    @Id
    @Column("id")
    private Long id;
    @Column("user_guid")
    private String userGuid;
    @Column("group_id")
    private String groupId;
    @Column("change_type")
    private String changeType; // e.g., "ASSIGN", "REVOKE"
    @Column("change_date")
    private LocalDateTime changeDate;
    @Column("changed_by")
    private String changedBy;
    private String reason;
}
