package com.llm.mcp.reactive.server.service.dataingestion;

import com.llm.mcp.reactive.server.domain.Employee;
import com.llm.mcp.reactive.server.domain.GroupMembership;
import com.llm.mcp.reactive.server.domain.Groupee;
import com.llm.mcp.reactive.server.repository.EmployeeRepository;
import com.llm.mcp.reactive.server.repository.GroupMembershipRepository;
import com.llm.mcp.reactive.server.repository.GroupRepository;
import com.llm.mcp.reactive.server.service.dataingestion.dto.EmployeeCsv;
import com.llm.mcp.reactive.server.service.dataingestion.dto.GroupMembershipCsv;
import com.llm.mcp.reactive.server.service.dataingestion.dto.GroupeeCsv;
import com.opencsv.bean.CsvToBeanBuilder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Mono;

import java.io.InputStreamReader;
import java.io.Reader;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class DataLoadingServiceViaCSV {

    private final ResourceLoader resourceLoader;
    private final GroupRepository groupeeRepository;
    private final EmployeeRepository employeeRepository;
    private final GroupMembershipRepository groupMembershipRepository;

    public DataLoadingServiceViaCSV(ResourceLoader resourceLoader, GroupRepository groupeeRepository, EmployeeRepository employeeRepository, GroupMembershipRepository groupMembershipRepository) {
        this.resourceLoader = resourceLoader;
        this.groupeeRepository = groupeeRepository;
        this.employeeRepository = employeeRepository;
        this.groupMembershipRepository = groupMembershipRepository;
    }

    @Transactional
    public Mono<Void> loadAllData() {
        log.info("Starting data load process...");
        return loadGroups()
                .then(loadEmployees())
                .then(loadMemberships())
                .doOnSuccess(v -> log.info("Data load process finished successfully."))
                .doOnError(e -> log.error("Data load process failed.", e));
    }

    private Mono<Void> loadGroups() {
        return groupeeRepository.count()
                .flatMap(count -> {
                    if (count == 0) {
                        log.info("Loading groups...");
                        try {
                            Resource resource = resourceLoader.getResource("classpath:csv/groups.csv");
                            try (Reader reader = new InputStreamReader(resource.getInputStream())) {
                                List<GroupeeCsv> csvList = new CsvToBeanBuilder<GroupeeCsv>(reader)
                                        .withType(GroupeeCsv.class).build().parse();
                                List<Groupee> groups = csvList.stream()
                                        .map(csv -> new Groupee(null, csv.getGroupId(), csv.getGroupName(), csv.getDescription(), csv.getResourceType()))
                                        .collect(Collectors.toList());
                                // 1. CORRECT: Use doOnComplete for a Flux. It runs after the last item is processed.
                                return groupeeRepository.saveAll(groups)
                                        .doOnComplete(() -> log.info("Finished loading {} groups.", groups.size()))
                                        .then();
                            }
                        } catch (Exception e) {
                            return Mono.error(new RuntimeException("Failed to load groups from CSV", e));
                        }
                    } else {
                        log.info("Group data already loaded with count {}.", count);
                        return Mono.empty();
                    }
                });
    }

    private Mono<Void> loadEmployees() {
        return employeeRepository.count()
                .flatMap(count -> {
                    if (count == 0) {
                        log.info("Loading employees...");
                        try {
                            Resource resource = resourceLoader.getResource("classpath:csv/employees.csv");
                            try (Reader reader = new InputStreamReader(resource.getInputStream())) {
                                List<EmployeeCsv> csvList = new CsvToBeanBuilder<EmployeeCsv>(reader)
                                        .withType(EmployeeCsv.class).build().parse();
                                List<Employee> employees = csvList.stream()
                                        .map(csv -> new Employee(null, csv.getUserGuid(), csv.getEmployeeId(), csv.getName(), csv.getDepartment(), csv.getRole(), csv.getJoinDate(), csv.getLineManagerId(), csv.isActive(), null, null, null))
                                        .collect(Collectors.toList());
                                // 2. CORRECT: Use doOnComplete here as well.
                                return employeeRepository.saveAll(employees)
                                        .doOnComplete(() -> log.info("Finished loading {} employees.", employees.size()))
                                        .then();
                            }
                        } catch (Exception e) {
                            return Mono.error(new RuntimeException("Failed to load employees from CSV", e));
                        }
                    } else {
                        log.info("Employee data already loaded with count {}.", count);
                        return Mono.empty();
                    }
                });
    }

    private Mono<Void> loadMemberships() {
        return groupMembershipRepository.count()
                .flatMap(count -> {
                    if (count == 0) {
                        log.info("Loading memberships...");
                        try {
                            Resource resource = resourceLoader.getResource("classpath:csv/memberships.csv");
                            try (Reader reader = new InputStreamReader(resource.getInputStream())) {
                                List<GroupMembershipCsv> csvList = new CsvToBeanBuilder<GroupMembershipCsv>(reader)
                                        .withType(GroupMembershipCsv.class).build().parse();
                                List<GroupMembership> memberships = csvList.stream()
                                        .map(csv -> new GroupMembership(null, csv.getUserGuid(), csv.getGroupId(), csv.getAssignedDate(), csv.getRevokedDate(), csv.getAssignedBy()))
                                        .collect(Collectors.toList());
                                // 3. CORRECT: And use doOnComplete for the final loading method.
                                return groupMembershipRepository.saveAll(memberships)
                                        .doOnComplete(() -> log.info("Finished loading {} memberships.", memberships.size()))
                                        .then();
                            }
                        } catch (Exception e) {
                            return Mono.error(new RuntimeException("Failed to load memberships from CSV", e));
                        }
                    } else {
                        log.info("Group membership data already loaded with count {}.", count);
                        return Mono.empty();
                    }
                });
    }
}