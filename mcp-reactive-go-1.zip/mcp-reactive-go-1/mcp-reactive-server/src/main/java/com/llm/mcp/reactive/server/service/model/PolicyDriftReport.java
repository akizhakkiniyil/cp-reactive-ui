package com.llm.mcp.reactive.server.service.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PolicyDriftReport {
    private String groupName;
    private LocalDate baselineDate;
    private List<String> addedMembersEmployeeIds;
    private List<String> removedMembersEmployeeIds;
}
