package com.llm.mcp.reactive.server.service.dataingestion.dto;

import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvDate;
import lombok.Data;

import java.time.LocalDate;

@Data
public class GroupMembershipCsv {
    @CsvBindByName(column = "userGuid") private String userGuid;
    @CsvBindByName(column = "groupId") private String groupId;
    @CsvDate("yyyy-MM-dd") @CsvBindByName(column = "assignedDate") private LocalDate assignedDate;
    @CsvDate("yyyy-MM-dd") @CsvBindByName(column = "revokedDate") private LocalDate revokedDate;
    @CsvBindByName(column = "assignedBy") private String assignedBy;
}
