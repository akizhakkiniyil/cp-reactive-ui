package com.llm.mcp.reactive.server.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Table("access_anomaly")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccessAnomaly {
    @Id
    @Column("id")
    private Long id;
    @Column("user_guid")
    private String userGuid;
    @Column("anomaly_type")
    private String anomalyType; // e.g., "Unusual_Group_Membership", "Excessive_Access_Growth"
    private String description;
    @Column("detected_date")
    private LocalDateTime detectedDate;
    private Double score; // Anomaly score
    private String status; // e.g., "Detected", "Reviewed", "Resolved"
}
