package com.llm.mcp.reactive.server.domain;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Table("groupee")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Groupee {
    @Id
    @Column("id")
    private Long id;
    @Column("group_id")
    private String groupId;
    @Column("group_name")
    private String groupName;
    @Column("description")
    private String description;
    @Column("resource_type")
    private String resourceType; // e.g., "Application", "SharePoint", "NetworkShare"
}
