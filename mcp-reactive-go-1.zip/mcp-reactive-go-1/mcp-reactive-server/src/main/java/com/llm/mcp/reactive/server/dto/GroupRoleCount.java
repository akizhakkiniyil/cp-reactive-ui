package com.llm.mcp.reactive.server.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO for representing the count of employees in a group for a specific role.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class GroupRoleCount {
    private int groupId;
    private Long count;
}