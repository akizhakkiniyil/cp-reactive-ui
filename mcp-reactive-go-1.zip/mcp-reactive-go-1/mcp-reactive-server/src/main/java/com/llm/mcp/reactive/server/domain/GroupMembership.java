package com.llm.mcp.reactive.server.domain;


import lombok.*;

import java.time.LocalDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Table("group_membership")
@Data
@NoArgsConstructor
@AllArgsConstructor
@RequiredArgsConstructor
@Builder(toBuilder = true)
public class GroupMembership {
    @Id
    @Column("id")
    private Long id; // Primary key for this entity
    @NonNull
    @Column("user_guid")
    private String userGuid;
    @NonNull
    @Column("group_id")
    private String groupId;
    @Column("assigned_date")
    private LocalDate assignedDate;
    @Column("revoked_date")
    private LocalDate revokedDate; // Null if still active
    @Column("assigned_by")
    private String assignedBy; // e.g., "HR", "IT", "Self-service"
}
