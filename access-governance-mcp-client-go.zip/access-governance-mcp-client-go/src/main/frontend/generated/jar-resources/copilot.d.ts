export { _registerImporter } from './copilot/figma-public/figma-api';
export type { FigmaNode } from './copilot/figma-public/figma-api';
export type { ComponentDefinition, ComponentDefinitionProperties } from './copilot/shared/flow-utils';
