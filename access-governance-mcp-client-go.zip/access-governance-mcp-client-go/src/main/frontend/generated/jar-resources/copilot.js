import { as as o } from "./copilot/copilot-CP3-W7yE.js";
export {
  o as _registerImporter
};
