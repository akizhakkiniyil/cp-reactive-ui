package com.hackathon.accessguardian.mcp.client;

import com.azure.core.http.HttpClient;
import com.azure.core.util.HttpClientOptions;
import com.vaadin.flow.theme.Theme;
import com.vaadin.flow.theme.lumo.Lumo;
import org.springframework.ai.azure.openai.AzureOpenAiChatModel;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.model.azure.openai.autoconfigure.AzureOpenAIClientBuilderCustomizer;
import org.springframework.ai.tool.ToolCallbackProvider;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.time.Duration;

@SpringBootApplication
public class SpringAiMacpClientApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringAiMacpClientApplication.class, args);
    }
    /* This also works
    */
    /* This is an attempt to make it working with the standard way of using builder , but it is not working as the chatClientBuilder is missing, will revisit later
    @Bean
    public AzureOpenAIClientBuilderCustomizer responseTimeoutCustomizer() {
        return openAiClientBuilder -> {
            HttpClientOptions clientOptions = new HttpClientOptions()
                    .setResponseTimeout(Duration.ofMinutes(5));
            openAiClientBuilder.httpClient(HttpClient.createDefault(clientOptions));
        };
    }

    @Bean
    public ChatClient alternateChatClient(ChatClient.Builder chatClientBuilder, ToolCallbackProvider tools) {
        // Create the builder directly from the injected ChatModel
        return chatClientBuilder
                .defaultSystem("Please prioritise context information for answering questions. Give short, concise and to the point answers.")
                .defaultToolCallbacks(tools)
                .build();
    }

    @Bean -- App started but getting error Sorry, an error occurred: java.lang.IllegalStateException: Multiple tools with the same name (test_mcp_client_server1_Get_Employee_Details_by_Name, test_mcp_client_server1_Generate_Access_Review_Summary, client_server1_Get_Peer_Group_Memberships_by_Role_and_Department, test_mcp_client_server1_Get_Employee_Context_Graph, test_mcp_client_server1_Get_Employee_Details, test_mcp_client_server1_Get_Group_Members, test_mcp_client_server1_Get_Group_Details, test_mcp_client_server1_Get_Department_Employees, test_mcp_client_server1_Detect_Access_Anomalies, test_mcp_client_server1_Get_Employee_Group_Memberships, test_mcp_client_server1_Get_Historical_Access_Changes, test_mcp_client_server1_Get_Direct_Reports, test_mcp_client_server1_Detect_Policy_Drift) found in ToolCallingChatOptions
    public ChatClient alternateChatClient(AzureOpenAiChatModel chatModel, ToolCallbackProvider tools) {
        // Create the builder directly from the injected ChatModel
        return ChatClient.builder(chatModel)
                .defaultSystem("Please prioritise context information for answering questions. Give short, concise and to the point answers.")
                .defaultToolCallbacks(tools)
                .build();
    }
*/
    @Bean
    public ChatClient chatClient(AzureOpenAiChatModel az) {
        return ChatClient.create(az);
    }


}
