package com.hackathon.accessguardian.mcp.client.controller;

import com.hackathon.accessguardian.mcp.client.dto.ChatRequest;
import com.hackathon.accessguardian.mcp.client.service.AccessGovernanceClientService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api")
@Slf4j
public class AiController {

    @Autowired
    private AccessGovernanceClientService aiAssistanceService;


    @PostMapping("/chat")
    // 4. Return a reactive type: Mono<String>
    public Mono<String> chatWithAi(@RequestBody ChatRequest request) {
        log.info("Received chat request with input: '{}'", request);

        // 5. The service call is now non-blocking and returns a Mono
        return aiAssistanceService.chatWithAi(request.getMessage())
                // 6. Handle errors reactively and gracefully
                .onErrorMap(e -> {
                    log.error("Error processing chat response from AI service", e);
                    // Remap the exception to a standard Spring exception for a clean error response
                    return new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error processing chat response", e);
                });
    }
}
